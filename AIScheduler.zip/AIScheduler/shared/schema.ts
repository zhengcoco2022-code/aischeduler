import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Class schedule entries (extracted from uploaded images) - per user
export const classEntries = pgTable("class_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  location: text("location"),
  color: text("color").default("#3b82f6"),
});

// Tasks that need to be scheduled - per user
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  duration: integer("duration").notNull(),
  deadline: timestamp("deadline"),
  priority: text("priority").notNull().default("medium"),
  category: text("category").notNull().default("personal"),
  isCompleted: boolean("is_completed").default(false),
  notes: text("notes"),
  isRecurring: boolean("is_recurring").default(false),
  repeatDays: text("repeat_days").array(),
});

// Scheduled time blocks (AI-generated placements) - per user
export const scheduledBlocks = pgTable("scheduled_blocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: varchar("task_id").references(() => tasks.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(),
  scheduledDate: text("scheduled_date"),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  isBreak: boolean("is_break").default(false),
  type: text("type").default("task"),
  source: text("source").default("manual"),
});

// User settings - per user
export const userSettings = pgTable("user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  sleepStart: text("sleep_start").default("23:00"),
  sleepEnd: text("sleep_end").default("07:00"),
  breakDuration: integer("break_duration").default(15),
  maxWorkHours: integer("max_work_hours").default(8),
  preferredStartTime: text("preferred_start_time").default("08:00"),
});

// Google OAuth tokens for calendar integration - per user
export const googleTokens = pgTable("google_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  email: text("email"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  classEntries: many(classEntries),
  tasks: many(tasks),
  scheduledBlocks: many(scheduledBlocks),
  settings: one(userSettings),
  googleTokens: one(googleTokens),
}));

export const classEntriesRelations = relations(classEntries, ({ one }) => ({
  user: one(users, {
    fields: [classEntries.userId],
    references: [users.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  user: one(users, {
    fields: [tasks.userId],
    references: [users.id],
  }),
  scheduledBlocks: many(scheduledBlocks),
}));

export const scheduledBlocksRelations = relations(scheduledBlocks, ({ one }) => ({
  user: one(users, {
    fields: [scheduledBlocks.userId],
    references: [users.id],
  }),
  task: one(tasks, {
    fields: [scheduledBlocks.taskId],
    references: [tasks.id],
  }),
}));

export const userSettingsRelations = relations(userSettings, ({ one }) => ({
  user: one(users, {
    fields: [userSettings.userId],
    references: [users.id],
  }),
}));

export const googleTokensRelations = relations(googleTokens, ({ one }) => ({
  user: one(users, {
    fields: [googleTokens.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertClassEntrySchema = createInsertSchema(classEntries).omit({
  id: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  isCompleted: true,
});

export const insertScheduledBlockSchema = createInsertSchema(scheduledBlocks).omit({
  id: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
});

export const insertGoogleTokensSchema = createInsertSchema(googleTokens).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertClassEntry = z.infer<typeof insertClassEntrySchema>;
export type ClassEntry = typeof classEntries.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertScheduledBlock = z.infer<typeof insertScheduledBlockSchema>;
export type ScheduledBlock = typeof scheduledBlocks.$inferSelect;

export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettings.$inferSelect;

export type InsertGoogleTokens = z.infer<typeof insertGoogleTokensSchema>;
export type GoogleTokens = typeof googleTokens.$inferSelect;

// Category colors for visual coding
export const categoryColors: Record<string, string> = {
  school: "#3b82f6",
  workout: "#ef4444",
  personal: "#8b5cf6",
  health: "#22c55e",
  other: "#f59e0b",
};

// Priority colors
export const priorityColors: Record<string, string> = {
  low: "#94a3b8",
  medium: "#3b82f6",
  high: "#f59e0b",
  urgent: "#ef4444",
};
