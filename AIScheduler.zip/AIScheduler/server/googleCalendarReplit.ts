// Google Calendar Integration using Replit's built-in connector
// This handles OAuth automatically through Replit's interface

import { google } from 'googleapis';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('Replit token not found');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=google-calendar',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings?.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Google Calendar not connected. Please connect it in the Replit Tools panel.');
  }
  return accessToken;
}

// Get a fresh Google Calendar client (never cache this)
export async function getGoogleCalendarClient() {
  const accessToken = await getAccessToken();

  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({
    access_token: accessToken
  });

  return google.calendar({ version: 'v3', auth: oauth2Client });
}

// Check if Google Calendar is connected
export async function checkGoogleCalendarConnection(): Promise<{ 
  connected: boolean; 
  email?: string;
  error?: string;
}> {
  try {
    const calendar = await getGoogleCalendarClient();
    const response = await calendar.calendarList.list({ maxResults: 1 });
    
    // Try to get user's primary calendar email
    const primaryCalendar = response.data.items?.find(cal => cal.primary);
    
    return { 
      connected: true,
      email: primaryCalendar?.id || undefined
    };
  } catch (error: any) {
    console.log('Google Calendar not connected:', error.message);
    return { 
      connected: false,
      error: error.message
    };
  }
}

// List available calendars
export async function listGoogleCalendars(): Promise<{ id: string; name: string; primary: boolean }[]> {
  const calendar = await getGoogleCalendarClient();
  const response = await calendar.calendarList.list();
  
  return (response.data.items || []).map(cal => ({
    id: cal.id || '',
    name: cal.summary || 'Unnamed Calendar',
    primary: cal.primary || false
  }));
}

// Import events from Google Calendar as class entries
export async function importEventsFromGoogleCalendar(
  calendarId: string = 'primary',
  daysAhead: number = 30
): Promise<{
  name: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  location?: string;
}[]> {
  const calendar = await getGoogleCalendarClient();
  
  const now = new Date();
  const future = new Date();
  future.setDate(future.getDate() + daysAhead);
  
  const response = await calendar.events.list({
    calendarId,
    timeMin: now.toISOString(),
    timeMax: future.toISOString(),
    singleEvents: true,
    orderBy: 'startTime',
    maxResults: 100
  });

  const events = response.data.items || [];
  const classEntries: {
    name: string;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    location?: string;
  }[] = [];

  for (const event of events) {
    if (!event.start?.dateTime || !event.end?.dateTime) continue;
    
    const startDate = new Date(event.start.dateTime);
    const endDate = new Date(event.end.dateTime);
    
    classEntries.push({
      name: event.summary || 'Untitled Event',
      dayOfWeek: startDate.getDay(),
      startTime: startDate.toTimeString().slice(0, 5),
      endTime: endDate.toTimeString().slice(0, 5),
      location: event.location || undefined
    });
  }

  return classEntries;
}
