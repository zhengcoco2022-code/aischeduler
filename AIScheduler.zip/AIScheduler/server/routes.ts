import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { extractScheduleFromImage, generateSchedule, calculateScheduleHealth, generateStudyPlan, generateStudyPlanOptions, parseNaturalLanguageRequest } from "./openai";
import { 
  checkGoogleCalendarConnection, 
  listGoogleCalendars, 
  importEventsFromGoogleCalendar,
  getGoogleAuthUrl,
  exchangeCodeForTokens,
  disconnectGoogleCalendar,
  validateOAuthState
} from "./googleCalendar";
import { insertClassEntrySchema, insertTaskSchema, insertUserSettingsSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

function getUserId(req: Request): string {
  const user = req.user as any;
  return user?.claims?.sub;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  await setupAuth(app);

  app.get('/api/auth/user', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/classes", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const classes = await storage.getAllClasses(userId);
      res.json(classes);
    } catch (error) {
      console.error("Error fetching classes:", error);
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post("/api/classes", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const parsed = insertClassEntrySchema.omit({ userId: true }).parse(req.body);
      const created = await storage.createClass({ ...parsed, userId });
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid class data", errors: error.errors });
      } else {
        console.error("Error creating class:", error);
        res.status(500).json({ message: "Failed to create class" });
      }
    }
  });

  app.post("/api/classes/bulk", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { classes } = req.body;
      if (!Array.isArray(classes)) {
        return res.status(400).json({ message: "Classes must be an array" });
      }
      
      const parsed = classes.map((c: any) => ({
        ...insertClassEntrySchema.omit({ userId: true }).parse(c),
        userId
      }));
      const created = await storage.createClassesBulk(parsed);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid class data", errors: error.errors });
      } else {
        console.error("Error creating classes:", error);
        res.status(500).json({ message: "Failed to create classes" });
      }
    }
  });

  app.patch("/api/classes/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const updates = insertClassEntrySchema.omit({ userId: true }).partial().parse(req.body);
      const updated = await storage.updateClass(userId, req.params.id, updates);
      if (!updated) {
        return res.status(404).json({ message: "Class not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid class data", errors: error.errors });
      } else {
        console.error("Error updating class:", error);
        res.status(500).json({ message: "Failed to update class" });
      }
    }
  });

  app.delete("/api/classes/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      await storage.deleteClass(userId, req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting class:", error);
      res.status(500).json({ message: "Failed to delete class" });
    }
  });

  app.get("/api/tasks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const tasks = await storage.getAllTasks(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const body = { ...req.body };
      if (body.deadline && typeof body.deadline === "string") {
        body.deadline = new Date(body.deadline);
      }
      const parsed = insertTaskSchema.omit({ userId: true }).parse(body);
      const created = await storage.createTask({ ...parsed, userId });
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid task data", errors: error.errors });
      } else {
        console.error("Error creating task:", error);
        res.status(500).json({ message: "Failed to create task" });
      }
    }
  });

  const updateTaskSchema = z.object({
    name: z.string().min(1).optional(),
    duration: z.number().min(5).optional(),
    deadline: z.union([z.string(), z.date(), z.null()]).optional(),
    priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
    category: z.enum(["school", "workout", "personal", "health", "other"]).optional(),
    isCompleted: z.boolean().optional(),
    notes: z.string().nullable().optional(),
  });

  app.patch("/api/tasks/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const parseResult = updateTaskSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid update data", 
          errors: parseResult.error.errors 
        });
      }

      const updates = parseResult.data;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }

      const processedUpdates: Record<string, any> = { ...updates };
      if (updates.deadline !== undefined && updates.deadline !== null && typeof updates.deadline === 'string') {
        processedUpdates.deadline = new Date(updates.deadline);
      }

      const updated = await storage.updateTask(userId, req.params.id, processedUpdates);
      if (!updated) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      await storage.deleteTask(userId, req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  app.get("/api/scheduled-blocks", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const blocks = await storage.getAllScheduledBlocks(userId);
      res.json(blocks);
    } catch (error) {
      console.error("Error fetching scheduled blocks:", error);
      res.status(500).json({ message: "Failed to fetch scheduled blocks" });
    }
  });

  app.patch("/api/scheduled-blocks/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { dayOfWeek, startTime } = req.body;
      
      if (typeof dayOfWeek !== "number" || dayOfWeek < 0 || dayOfWeek > 6) {
        return res.status(400).json({ message: "Invalid day of week" });
      }
      
      if (!startTime || !/^\d{2}:\d{2}$/.test(startTime)) {
        return res.status(400).json({ message: "Invalid start time format (expected HH:MM)" });
      }
      
      const block = await storage.getScheduledBlock(userId, req.params.id);
      if (!block) {
        return res.status(404).json({ message: "Block not found" });
      }

      const [oldStartH, oldStartM] = block.startTime.split(":").map(Number);
      const [oldEndH, oldEndM] = block.endTime.split(":").map(Number);
      const durationMinutes = (oldEndH * 60 + oldEndM) - (oldStartH * 60 + oldStartM);

      const [newStartH, newStartM] = startTime.split(":").map(Number);
      const newEndMinutes = newStartH * 60 + newStartM + durationMinutes;
      
      if (newEndMinutes > 24 * 60) {
        return res.status(400).json({ message: "End time would exceed midnight" });
      }
      
      const newEndTime = `${Math.floor(newEndMinutes / 60).toString().padStart(2, "0")}:${(newEndMinutes % 60).toString().padStart(2, "0")}`;

      const updated = await storage.updateScheduledBlock(userId, req.params.id, {
        dayOfWeek,
        startTime,
        endTime: newEndTime,
      });
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating scheduled block:", error);
      res.status(500).json({ message: "Failed to update scheduled block" });
    }
  });

  app.post("/api/schedule/extract", isAuthenticated, upload.single("image"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const base64Image = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
      const classes = await extractScheduleFromImage(base64Image);
      
      res.json({ classes });
    } catch (error) {
      console.error("Error extracting schedule:", error);
      const message = error instanceof Error ? error.message : "Failed to extract schedule";
      res.status(500).json({ message });
    }
  });

  app.post("/api/schedule/generate", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      
      const [tasks, classes, settings] = await Promise.all([
        storage.getAllTasks(userId),
        storage.getAllClasses(userId),
        storage.getSettings(userId),
      ]);

      const pendingTasks = tasks.filter(t => !t.isCompleted);
      
      if (pendingTasks.length === 0) {
        return res.json({ message: "No pending tasks to schedule", blocks: [] });
      }

      const effectiveSettings = {
        sleepStart: settings?.sleepStart || "23:00",
        sleepEnd: settings?.sleepEnd || "07:00",
        breakDuration: settings?.breakDuration || 15,
        maxWorkHours: settings?.maxWorkHours || 8,
        preferredStartTime: settings?.preferredStartTime || "08:00",
      };

      const scheduleBlocks = await generateSchedule(
        pendingTasks.map(t => ({
          id: t.id,
          name: t.name,
          duration: t.duration,
          deadline: t.deadline,
          priority: t.priority,
          category: t.category,
        })),
        classes.map(c => ({
          dayOfWeek: c.dayOfWeek,
          startTime: c.startTime,
          endTime: c.endTime,
        })),
        effectiveSettings
      );

      await storage.deleteAllScheduledBlocks(userId);

      const today = new Date();
      const currentDay = today.getDay();
      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - currentDay);
      weekStart.setHours(0, 0, 0, 0);

      const blocksToCreate = scheduleBlocks.map(block => {
        const blockDate = new Date(weekStart);
        blockDate.setDate(weekStart.getDate() + block.dayOfWeek);
        const scheduledDate = blockDate.toISOString().split('T')[0];

        return {
          userId,
          taskId: block.taskId || null,
          dayOfWeek: block.dayOfWeek,
          scheduledDate,
          startTime: block.startTime,
          endTime: block.endTime,
          isBreak: block.isBreak,
          type: block.isBreak ? "break" : "task",
        };
      });

      const created = await storage.createScheduledBlocksBulk(blocksToCreate);
      
      res.json({ blocks: created });
    } catch (error) {
      console.error("Error generating schedule:", error);
      const message = error instanceof Error ? error.message : "Failed to generate schedule";
      res.status(500).json({ message });
    }
  });

  app.get("/api/schedule/health", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      
      const [blocks, settings] = await Promise.all([
        storage.getAllScheduledBlocks(userId),
        storage.getSettings(userId),
      ]);

      const maxWorkHours = settings?.maxWorkHours || 8;
      const health = calculateScheduleHealth(
        blocks.map(b => ({
          dayOfWeek: b.dayOfWeek,
          startTime: b.startTime,
          endTime: b.endTime,
          isBreak: b.isBreak || false,
        })),
        maxWorkHours
      );

      res.json(health);
    } catch (error) {
      console.error("Error calculating schedule health:", error);
      res.status(500).json({ message: "Failed to calculate schedule health" });
    }
  });

  app.post("/api/schedule/study-plan", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      
      const [tasks, classes, settings, blocks] = await Promise.all([
        storage.getAllTasks(userId),
        storage.getAllClasses(userId),
        storage.getSettings(userId),
        storage.getAllScheduledBlocks(userId),
      ]);

      const pendingTasks = tasks.filter(t => !t.isCompleted);
      
      if (pendingTasks.length === 0) {
        return res.json({ 
          overallAdvice: "You have no pending tasks! Take some time to relax or plan ahead.",
          weeklyGoals: [],
          recommendations: [],
          warnings: []
        });
      }

      const effectiveSettings = {
        sleepStart: settings?.sleepStart || "23:00",
        sleepEnd: settings?.sleepEnd || "07:00",
        breakDuration: settings?.breakDuration || 15,
        maxWorkHours: settings?.maxWorkHours || 8,
        preferredStartTime: settings?.preferredStartTime || "08:00",
      };

      const studyPlan = await generateStudyPlan(
        pendingTasks.map(t => ({
          id: t.id,
          name: t.name,
          duration: t.duration,
          deadline: t.deadline,
          priority: t.priority,
          category: t.category,
        })),
        classes.map(c => ({
          dayOfWeek: c.dayOfWeek,
          startTime: c.startTime,
          endTime: c.endTime,
        })),
        effectiveSettings,
        blocks.map(b => ({
          dayOfWeek: b.dayOfWeek,
          startTime: b.startTime,
          endTime: b.endTime,
          isBreak: b.isBreak || false,
        }))
      );

      res.json(studyPlan);
    } catch (error) {
      console.error("Error generating study plan:", error);
      const message = error instanceof Error ? error.message : "Failed to generate study plan";
      res.status(500).json({ message });
    }
  });

  app.post("/api/schedule/study-plan-options", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      
      const [tasks, classes, settings, blocks] = await Promise.all([
        storage.getAllTasks(userId),
        storage.getAllClasses(userId),
        storage.getSettings(userId),
        storage.getAllScheduledBlocks(userId),
      ]);

      const pendingTasks = tasks.filter(t => !t.isCompleted);
      
      if (pendingTasks.length === 0) {
        return res.json({ 
          overallAdvice: "You have no pending tasks! Take some time to relax or plan ahead.",
          weeklyGoals: [],
          warnings: [],
          planOptions: []
        });
      }

      const effectiveSettings = {
        sleepStart: settings?.sleepStart || "23:00",
        sleepEnd: settings?.sleepEnd || "07:00",
        breakDuration: settings?.breakDuration || 15,
        maxWorkHours: settings?.maxWorkHours || 8,
        preferredStartTime: settings?.preferredStartTime || "08:00",
      };

      const studyPlanWithOptions = await generateStudyPlanOptions(
        pendingTasks.map(t => ({
          id: t.id,
          name: t.name,
          duration: t.duration,
          deadline: t.deadline,
          priority: t.priority,
          category: t.category,
        })),
        classes.map(c => ({
          dayOfWeek: c.dayOfWeek,
          startTime: c.startTime,
          endTime: c.endTime,
          name: c.name,
        })),
        effectiveSettings,
        blocks.map(b => ({
          dayOfWeek: b.dayOfWeek,
          startTime: b.startTime,
          endTime: b.endTime,
          isBreak: b.isBreak || false,
          scheduledDate: (b as any).scheduledDate,
        }))
      );

      res.json(studyPlanWithOptions);
    } catch (error) {
      console.error("Error generating study plan options:", error);
      const message = error instanceof Error ? error.message : "Failed to generate study plan options";
      res.status(500).json({ message });
    }
  });

  app.post("/api/schedule/apply-plan-option", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { sessions } = req.body;
      
      if (!sessions || !Array.isArray(sessions) || sessions.length === 0) {
        return res.status(400).json({ message: "No sessions to apply" });
      }

      await storage.deleteAllScheduledBlocks(userId);

      const blocksToCreate = sessions.map((session: any) => ({
        userId,
        taskId: session.taskId || null,
        dayOfWeek: session.dayOfWeek,
        scheduledDate: session.scheduledDate,
        startTime: session.startTime,
        endTime: session.endTime,
        isBreak: false,
        type: "task",
        source: "study_plan",
      }));

      const created = await storage.createScheduledBlocksBulk(blocksToCreate);
      
      res.json({ 
        message: `Successfully scheduled ${created.length} study sessions`,
        blocks: created 
      });
    } catch (error) {
      console.error("Error applying study plan option:", error);
      const message = error instanceof Error ? error.message : "Failed to apply study plan";
      res.status(500).json({ message });
    }
  });

  app.post("/api/schedule/apply-study-plan", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { recommendations } = req.body;
      
      if (!recommendations || !Array.isArray(recommendations) || recommendations.length === 0) {
        return res.status(400).json({ message: "No recommendations to apply" });
      }

      await storage.deleteAllScheduledBlocks(userId);

      const today = new Date();
      const currentDay = today.getDay();
      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - currentDay);
      weekStart.setHours(0, 0, 0, 0);

      const blocksToCreate: any[] = [];

      for (const rec of recommendations) {
        const { taskId, taskName, recommendations: recs } = rec;
        
        if (!recs || !recs.bestTimes || recs.bestTimes.length === 0) continue;

        for (const timeSlot of recs.bestTimes) {
          const dayMatch = timeSlot.match(/^(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)/i);
          const timeMatch = timeSlot.match(/(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
          
          if (dayMatch && timeMatch) {
            const dayName = dayMatch[1];
            const days: { [key: string]: number } = {
              'sunday': 0, 'monday': 1, 'tuesday': 2, 'wednesday': 3,
              'thursday': 4, 'friday': 5, 'saturday': 6
            };
            const dayOfWeek = days[dayName.toLowerCase()];
            
            let startHour = parseInt(timeMatch[1]);
            let startMin = parseInt(timeMatch[2]);
            let endHour = parseInt(timeMatch[3]);
            let endMin = parseInt(timeMatch[4]);
            const period = timeMatch[5]?.toUpperCase();
            
            if (period === 'PM' && startHour !== 12) startHour += 12;
            if (period === 'AM' && startHour === 12) startHour = 0;
            if (period === 'PM' && endHour !== 12) endHour += 12;
            if (period === 'AM' && endHour === 12) endHour = 0;
            
            const blockDate = new Date(weekStart);
            blockDate.setDate(weekStart.getDate() + dayOfWeek);
            const scheduledDate = blockDate.toISOString().split('T')[0];
            
            const startTime = `${startHour.toString().padStart(2, '0')}:${startMin.toString().padStart(2, '0')}`;
            const endTime = `${endHour.toString().padStart(2, '0')}:${endMin.toString().padStart(2, '0')}`;
            
            blocksToCreate.push({
              userId,
              taskId: taskId || null,
              dayOfWeek,
              scheduledDate,
              startTime,
              endTime,
              isBreak: false,
              type: "task",
              source: "study_plan",
            });
            
            break;
          }
        }
      }

      if (blocksToCreate.length === 0) {
        return res.status(400).json({ message: "Could not parse any recommendations into schedule blocks" });
      }

      const created = await storage.createScheduledBlocksBulk(blocksToCreate);
      
      res.json({ 
        message: `Successfully scheduled ${created.length} tasks`,
        blocks: created 
      });
    } catch (error) {
      console.error("Error applying study plan:", error);
      const message = error instanceof Error ? error.message : "Failed to apply study plan";
      res.status(500).json({ message });
    }
  });

  app.get("/api/settings", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      let settings = await storage.getSettings(userId);
      
      if (!settings) {
        settings = await storage.upsertSettings({
          userId,
          sleepStart: "23:00",
          sleepEnd: "07:00",
          breakDuration: 15,
          maxWorkHours: 8,
          preferredStartTime: "08:00",
        });
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.put("/api/settings", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const parsed = insertUserSettingsSchema.omit({ userId: true }).parse(req.body);
      const updated = await storage.upsertSettings({ ...parsed, userId });
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      } else {
        console.error("Error updating settings:", error);
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  app.get("/api/auth/google", isAuthenticated, async (_req: Request, res: Response) => {
    try {
      const { url } = getGoogleAuthUrl();
      res.json({ authUrl: url });
    } catch (error) {
      console.error("Error generating auth URL:", error);
      const message = error instanceof Error ? error.message : "Failed to generate authorization URL";
      res.status(500).json({ message });
    }
  });

  app.get("/api/auth/google/callback", async (req: Request, res: Response) => {
    try {
      const { code, state, error } = req.query;
      
      if (error) {
        console.error("OAuth error:", error);
        return res.redirect("/?google_auth=error&message=" + encodeURIComponent(String(error)));
      }
      
      if (!code || typeof code !== "string") {
        return res.redirect("/?google_auth=error&message=No authorization code received");
      }
      
      if (!state || typeof state !== "string" || !validateOAuthState(state)) {
        return res.redirect("/?google_auth=error&message=Invalid state parameter");
      }
      
      const user = req.user as any;
      if (!user?.claims?.sub) {
        return res.redirect("/?google_auth=error&message=Please login first");
      }
      
      const userId = user.claims.sub;
      const tokens = await exchangeCodeForTokens(code);
      
      await storage.saveGoogleTokens({
        userId,
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: tokens.expiresAt,
        email: tokens.email
      });
      
      res.redirect("/?google_auth=success");
    } catch (error) {
      console.error("OAuth callback error:", error);
      const message = error instanceof Error ? error.message : "Authentication failed";
      res.redirect("/?google_auth=error&message=" + encodeURIComponent(message));
    }
  });

  app.post("/api/google-calendar/disconnect", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      await storage.deleteGoogleTokens(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error disconnecting Google Calendar:", error);
      res.status(500).json({ message: "Failed to disconnect Google Calendar" });
    }
  });
  
  app.get("/api/google-calendar/status", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const status = await checkGoogleCalendarConnection(userId);
      res.json(status);
    } catch (error) {
      console.error("Error checking Google Calendar status:", error);
      res.json({ connected: false });
    }
  });

  app.get("/api/google-calendar/calendars", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const calendars = await listGoogleCalendars(userId);
      res.json(calendars);
    } catch (error) {
      console.error("Error listing calendars:", error);
      res.status(500).json({ message: "Failed to list calendars. Make sure Google Calendar is connected." });
    }
  });

  app.post("/api/google-calendar/import", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { calendarId = 'primary', daysAhead = 30 } = req.body;
      
      const events = await importEventsFromGoogleCalendar(userId, calendarId, daysAhead);
      
      const createdClasses = [];
      for (const event of events) {
        try {
          const created = await storage.createClass({
            userId,
            name: event.name,
            dayOfWeek: event.dayOfWeek,
            startTime: event.startTime,
            endTime: event.endTime,
            location: event.location || null,
          });
          createdClasses.push(created);
        } catch (err) {
          console.error("Error saving imported class:", err);
        }
      }
      
      res.json({ 
        imported: createdClasses.length,
        total: events.length,
        classes: createdClasses
      });
    } catch (error) {
      console.error("Error importing from Google Calendar:", error);
      const message = error instanceof Error ? error.message : "Failed to import from Google Calendar";
      res.status(500).json({ message });
    }
  });

  app.post("/api/chat/task", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = getUserId(req);
      const { message } = req.body;
      
      if (!message || typeof message !== "string") {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const [classes, tasks, settings] = await Promise.all([
        storage.getAllClasses(userId),
        storage.getAllTasks(userId),
        storage.getSettings(userId)
      ]);
      
      const parsed = await parseNaturalLanguageRequest(
        message,
        classes.map(c => ({
          name: c.name,
          dayOfWeek: c.dayOfWeek,
          startTime: c.startTime,
          endTime: c.endTime
        })),
        tasks.map(t => ({
          name: t.name,
          isRecurring: t.isRecurring || false,
          repeatDays: t.repeatDays
        })),
        {
          sleepStart: settings?.sleepStart || "23:00",
          sleepEnd: settings?.sleepEnd || "07:00"
        }
      );
      
      if (!parsed.understood) {
        return res.json({
          success: false,
          response: parsed.response,
          task: null,
          classes: null
        });
      }
      
      const validPriorities = ["low", "medium", "high", "urgent"];
      const validCategories = ["school", "workout", "personal", "health", "other"];
      const validDays = ["0", "1", "2", "3", "4", "5", "6"];
      
      let createdTask = null;
      let createdClasses: any[] = [];
      
      // Create task if the AI determined we need one
      if (parsed.type === "task" || parsed.type === "both") {
        if (parsed.task) {
          const priority = validPriorities.includes(parsed.task.priority) 
            ? parsed.task.priority 
            : "medium";
          const category = validCategories.includes(parsed.task.category) 
            ? parsed.task.category 
            : "personal";
          
          const duration = Math.max(5, Math.min(480, parsed.task.duration || 30));
          
          const repeatDays = parsed.task.repeatDays 
            ? parsed.task.repeatDays.filter(d => validDays.includes(d))
            : null;
          
          const taskData = {
            userId,
            name: parsed.task.name || "New Task",
            duration,
            priority,
            category,
            notes: parsed.task.notes,
            isRecurring: parsed.task.isRecurring && repeatDays && repeatDays.length > 0,
            repeatDays: parsed.task.isRecurring ? repeatDays : null,
            deadline: parsed.task.deadline ? new Date(parsed.task.deadline) : null
          };
          
          const validated = insertTaskSchema.parse(taskData);
          createdTask = await storage.createTask(validated);
        }
      }
      
      // Create classes if the AI determined we need them
      if (parsed.type === "class" || parsed.type === "both") {
        const classesToCreate = parsed.multipleClasses || (parsed.classEntry ? [parsed.classEntry] : []);
        
        for (const classEntry of classesToCreate) {
          if (classEntry && classEntry.name && classEntry.startTime && classEntry.endTime) {
            const dayOfWeek = typeof classEntry.dayOfWeek === 'number' 
              ? Math.max(0, Math.min(6, classEntry.dayOfWeek)) 
              : 1;
            
            const classData = {
              userId,
              name: classEntry.name,
              dayOfWeek,
              startTime: classEntry.startTime,
              endTime: classEntry.endTime,
              location: classEntry.location || null,
              color: classEntry.color || "#3b82f6"
            };
            
            const validated = insertClassEntrySchema.parse(classData);
            const created = await storage.createClass(validated);
            createdClasses.push(created);
          }
        }
      }
      
      res.json({
        success: true,
        type: parsed.type,
        response: parsed.response,
        task: createdTask,
        classes: createdClasses.length > 0 ? createdClasses : null,
        scheduling: parsed.scheduling
      });
      
    } catch (error) {
      console.error("Error processing chat request:", error);
      const message = error instanceof Error ? error.message : "Failed to process your request";
      res.status(500).json({ 
        success: false,
        message,
        response: "I'm sorry, I had trouble understanding that. Could you try rephrasing your request?"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
