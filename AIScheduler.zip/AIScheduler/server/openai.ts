// Using Replit's AI Integrations service for OpenAI-compatible API access
import OpenAI from "openai";

// This uses Replit's AI Integrations, which provides OpenAI-compatible API access
// without requiring your own OpenAI API key. Charges are billed to your Replit credits.
const openai = new OpenAI({ 
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

interface ExtractedClass {
  name: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  location?: string;
}

interface ScheduleBlock {
  taskId: string;
  taskName: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isBreak: boolean;
}

interface ScheduleSettings {
  sleepStart: string;
  sleepEnd: string;
  breakDuration: number;
  maxWorkHours: number;
  preferredStartTime: string;
}

interface TaskToSchedule {
  id: string;
  name: string;
  duration: number;
  deadline: Date | null;
  priority: string;
  category: string;
}

interface ClassBlock {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

export async function extractScheduleFromImage(base64Image: string): Promise<ExtractedClass[]> {
  const prompt = `You are an expert OCR and schedule extraction system. Your job is to analyze ANY image and extract schedule/timetable/calendar information from it.

ANALYZE THIS IMAGE THOROUGHLY. Look for ANY of the following:
- Class schedules, course timetables, university schedules
- Work schedules, shift schedules, employee rosters
- Meeting calendars, appointment schedules
- Event calendars, activity schedules
- Handwritten schedules or notes with times
- Screenshots from calendar apps (Google Calendar, Outlook, etc.)
- Tables, grids, or lists with time information
- ANY text that mentions days of the week and times

EXTRACTION RULES:
1. First, carefully READ ALL TEXT in the image - every word, number, and symbol
2. Look for patterns: day names (Mon, Monday, M, etc.), times (9:00, 9am, 0900, etc.)
3. Identify recurring events/classes/activities
4. If you see a grid/table, use row and column headers to determine days and times
5. For each event found, extract:
   - Name: The activity/class/event name (be descriptive, include course codes if visible)
   - Day: Convert to number (Sunday=0, Monday=1, Tuesday=2, Wednesday=3, Thursday=4, Friday=5, Saturday=6)
   - Start time: In 24-hour format HH:MM
   - End time: In 24-hour format HH:MM (if not visible, estimate based on context or add 1 hour)
   - Location: Room/building/location if mentioned (optional)

HANDLING DIFFERENT FORMATS:
- 12-hour time (9:30 AM) → convert to 24-hour (09:30)
- Abbreviations (M/W/F, TTh, MWF) → expand to individual day entries
- Time ranges (9-10:30) → extract start and end
- If only duration given (1.5 hours), calculate end time from start
- Handwritten text: do your best to interpret
- Blurry/unclear: make reasonable guesses

BE AGGRESSIVE ABOUT EXTRACTION:
- If you see ANY schedule-like information, extract it
- Better to extract something imperfect than nothing
- Make educated guesses for unclear information
- Look at the ENTIRE image, including corners and edges

Return a JSON array with this structure:
[
  {
    "name": "Event/Class Name",
    "dayOfWeek": 1,
    "startTime": "09:00",
    "endTime": "10:30",
    "location": "Room 101"
  }
]

IMPORTANT: If an event repeats on multiple days, create SEPARATE entries for each day.
Only return an empty array [] if there is absolutely NO schedule information in the image.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert OCR system specialized in reading schedules, timetables, and calendars from images. You can read text from photos, screenshots, handwritten notes, and any image format. Always extract as much schedule information as possible. Be thorough and aggressive - it's better to extract imperfect data than to miss information."
        },
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            {
              type: "image_url",
              image_url: {
                url: base64Image.startsWith("data:") ? base64Image : `data:image/jpeg;base64,${base64Image}`,
                detail: "high",
              },
            },
          ],
        },
      ],
      max_completion_tokens: 4096,
    });

    const content = response.choices[0].message.content || "[]";
    
    // Extract JSON from the response - try multiple patterns
    let jsonMatch = content.match(/\[[\s\S]*\]/);
    
    // If no array found, try to find JSON object with classes/schedule array
    if (!jsonMatch) {
      const objectMatch = content.match(/\{[\s\S]*"(?:classes|schedule|events|entries)"[\s\S]*\}/);
      if (objectMatch) {
        try {
          const obj = JSON.parse(objectMatch[0]);
          const arr = obj.classes || obj.schedule || obj.events || obj.entries || [];
          return arr as ExtractedClass[];
        } catch (e) {
          console.error("Failed to parse object response:", e);
        }
      }
    }
    
    if (!jsonMatch) {
      console.error("No JSON array found in response:", content);
      return [];
    }

    const parsed = JSON.parse(jsonMatch[0]);
    return parsed as ExtractedClass[];
  } catch (error: any) {
    console.error("Error extracting schedule:", error);
    
    // Provide more specific error messages based on the error type
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    if (error?.status === 400) {
      throw new Error("The image could not be processed. Please try a different image format (PNG or JPG recommended).");
    }
    
    throw new Error("Failed to extract schedule from image. Please try again.");
  }
}

export async function generateSchedule(
  tasks: TaskToSchedule[],
  classes: ClassBlock[],
  settings: ScheduleSettings
): Promise<ScheduleBlock[]> {
  if (tasks.length === 0) {
    return [];
  }

  const prompt = `You are an AI scheduling assistant. Generate an optimal weekly schedule for the following tasks, considering the existing class schedule and user preferences.

EXISTING CLASSES (some are blocked, some are work time):
${JSON.stringify(classes, null, 2)}

IMPORTANT: "Study Hall" classes are AVAILABLE TIME for completing tasks - schedule work during study hall periods!

TASKS TO SCHEDULE:
${JSON.stringify(tasks.map(t => ({
  id: t.id,
  name: t.name,
  durationMinutes: t.duration,
  deadline: t.deadline ? new Date(t.deadline).toISOString() : null,
  priority: t.priority,
  category: t.category
})), null, 2)}

TODAY'S DATE: ${new Date().toISOString().split('T')[0]}
CURRENT DAY OF WEEK: ${new Date().getDay()} (0=Sunday, 6=Saturday)

USER SETTINGS:
- Sleep time: ${settings.sleepStart} to ${settings.sleepEnd} (NEVER schedule during sleep hours!)
- Preferred start time: ${settings.preferredStartTime}
- Max work hours per day: ${settings.maxWorkHours}
- Break duration between tasks: ${settings.breakDuration} minutes

BLOCKED TIME PERIODS (do NOT schedule tasks during these):
- Sleep hours: ${settings.sleepStart} to ${settings.sleepEnd}
- Dinner time: 17:30 to 19:00 (5:30 PM to 7:00 PM)
- Regular classes (except Study Hall which is work time)

CRITICAL DEADLINE RULES:
1. ALL tasks with deadlines MUST be completed BEFORE their deadline date
2. If a task has a deadline of Dec 5, ALL sessions for that task must end by Dec 4
3. Schedule high-priority and urgent tasks with deadlines FIRST
4. If a deadline is impossible to meet, still schedule as early as possible

SCHEDULING RULES:
1. Never schedule during sleep hours or dinner time (17:30-19:00)
2. USE Study Hall periods for completing homework and tasks - this is ideal work time!
3. Split long tasks (>90 min) into multiple sessions with breaks
4. Prioritize tasks by: deadline proximity > priority level > duration
5. Spread workload evenly but front-load tasks with near deadlines
6. Add ${settings.breakDuration} minute breaks between intensive work sessions
7. Schedule from today forward (current day = ${new Date().getDay()})

Return ONLY a JSON array with this exact structure (no other text):
[
  {
    "taskId": "task-uuid-here",
    "taskName": "Task Name",
    "dayOfWeek": 1,
    "startTime": "10:00",
    "endTime": "11:30",
    "isBreak": false
  },
  {
    "taskId": null,
    "taskName": "Break",
    "dayOfWeek": 1,
    "startTime": "11:30",
    "endTime": "11:45",
    "isBreak": true
  }
]

Generate a complete weekly schedule placing all tasks in appropriate time slots, ensuring all deadlines are met.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert scheduling AI that creates healthy, balanced, and productive schedules. Always respond with valid JSON only.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 4096,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    
    // Handle both array and object with schedule key
    const schedule = Array.isArray(parsed) ? parsed : (parsed.schedule || parsed.blocks || []);
    
    return schedule as ScheduleBlock[];
  } catch (error: any) {
    console.error("Error generating schedule:", error);
    
    // Provide more specific error messages based on the error type
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    
    throw new Error("Failed to generate schedule. Please try again.");
  }
}

export function calculateScheduleHealth(
  scheduledBlocks: { dayOfWeek: number; startTime: string; endTime: string; isBreak: boolean }[],
  maxWorkHours: number
): { isOverloaded: boolean; message: string; hoursPerDay: Record<string, number> } {
  const hoursPerDay: Record<string, number> = {
    "0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0
  };

  for (const block of scheduledBlocks) {
    if (block.isBreak) continue;
    
    const [startH, startM] = block.startTime.split(":").map(Number);
    const [endH, endM] = block.endTime.split(":").map(Number);
    const durationHours = ((endH * 60 + endM) - (startH * 60 + startM)) / 60;
    
    hoursPerDay[block.dayOfWeek.toString()] += durationHours;
  }

  const overloadedDays = Object.entries(hoursPerDay)
    .filter(([_, hours]) => hours > maxWorkHours)
    .map(([day]) => {
      const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      return days[parseInt(day)];
    });

  const isOverloaded = overloadedDays.length > 0;
  const message = isOverloaded
    ? `Your schedule exceeds ${maxWorkHours} hours on ${overloadedDays.join(", ")}. Consider reducing tasks or adjusting settings.`
    : "Your schedule looks healthy!";

  return { isOverloaded, message, hoursPerDay };
}

// Study plan recommendation interface
export interface StudyPlanRecommendation {
  taskId: string;
  taskName: string;
  recommendations: {
    bestTimes: string[];
    shouldBreakDown: boolean;
    breakdownSuggestion?: string;
    estimatedSessions: number;
    sessionDuration: number;
    priorityReason: string;
    studyTips: string[];
  };
}

// Individual study session for a plan
export interface StudySession {
  taskId: string;
  taskName: string;
  dayOfWeek: number;
  scheduledDate: string; // YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
}

// A single study plan option
export interface StudyPlanOption {
  id: string;
  name: string; // e.g., "Conservative Plan", "Balanced Plan", "Intensive Plan"
  description: string;
  totalHours: number;
  sessionsPerDay: Record<string, number>; // "Monday": 2, etc.
  sessions: StudySession[];
  pros: string[];
  cons: string[];
}

export interface StudyPlan {
  overallAdvice: string;
  weeklyGoals: string[];
  recommendations: StudyPlanRecommendation[];
  warnings: string[];
}

// Enhanced study plan with multiple options
export interface StudyPlanWithOptions {
  overallAdvice: string;
  weeklyGoals: string[];
  warnings: string[];
  planOptions: StudyPlanOption[];
}

// Helper to format date as YYYY-MM-DD
function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

// Helper to get next N days
function getNextDays(count: number): { date: Date; dateStr: string; dayOfWeek: number; dayName: string }[] {
  const days = [];
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  for (let i = 0; i < count; i++) {
    const date = new Date();
    date.setDate(date.getDate() + i);
    days.push({
      date,
      dateStr: formatDate(date),
      dayOfWeek: date.getDay(),
      dayName: dayNames[date.getDay()]
    });
  }
  return days;
}

// Generate multiple study plan options
export async function generateStudyPlanOptions(
  tasks: TaskToSchedule[],
  classes: ClassBlock[],
  settings: ScheduleSettings,
  existingBlocks: { dayOfWeek: number; startTime: string; endTime: string; isBreak: boolean; scheduledDate?: string }[]
): Promise<StudyPlanWithOptions> {
  if (tasks.length === 0) {
    return {
      overallAdvice: "No tasks to schedule. Add some tasks first!",
      weeklyGoals: [],
      warnings: [],
      planOptions: []
    };
  }

  // Get next 14 days for scheduling
  const upcomingDays = getNextDays(14);
  
  // Build comprehensive blocked time list
  const blockedTimesByDay: Record<string, { start: string; end: string; reason: string }[]> = {};
  
  upcomingDays.forEach(day => {
    blockedTimesByDay[day.dateStr] = [];
    
    // Add sleep hours (overnight handling)
    const sleepStart = settings.sleepStart;
    const sleepEnd = settings.sleepEnd;
    
    // Sleep typically spans midnight (e.g., 22:00 to 07:00)
    const [sleepStartH] = sleepStart.split(':').map(Number);
    const [sleepEndH] = sleepEnd.split(':').map(Number);
    
    if (sleepStartH > sleepEndH) {
      // Sleep spans midnight
      blockedTimesByDay[day.dateStr].push({ start: sleepStart, end: "23:59", reason: "Sleep" });
      blockedTimesByDay[day.dateStr].push({ start: "00:00", end: sleepEnd, reason: "Sleep" });
    } else {
      blockedTimesByDay[day.dateStr].push({ start: sleepStart, end: sleepEnd, reason: "Sleep" });
    }
    
    // Add lunch (12:00 - 13:00)
    blockedTimesByDay[day.dateStr].push({ start: "12:00", end: "13:00", reason: "Lunch" });
    
    // Add dinner (17:30 - 19:00)
    blockedTimesByDay[day.dateStr].push({ start: "17:30", end: "19:00", reason: "Dinner" });
    
    // Add classes for this day of week (except Study Hall)
    classes.forEach(cls => {
      if (cls.dayOfWeek === day.dayOfWeek) {
        // Check if this is Study Hall (available time, not blocked)
        // We'll pass this info but mark it differently
      }
    });
  });

  // Compact task format to reduce tokens
  const compactTasks = tasks.map(t => ({
    id: t.id,
    n: t.name,
    d: t.duration,
    dl: t.deadline ? new Date(t.deadline).toISOString().split('T')[0] : null,
    p: t.priority
  }));

  // Compact class format with Study Hall detection
  const compactClasses = classes.map(c => {
    const className = (c as any).name || 'Class';
    const isStudyHall = className.toLowerCase().includes('study hall') || 
                        className.toLowerCase().includes('study period') ||
                        className.toLowerCase().includes('free period');
    return {
      n: className,
      day: c.dayOfWeek,
      dayName: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][c.dayOfWeek],
      s: c.startTime,
      e: c.endTime,
      study: isStudyHall
    };
  });

  // Only include non-empty existing blocks
  const compactBlocks = existingBlocks.filter(b => !b.isBreak).map(b => ({
    day: b.dayOfWeek,
    dt: b.scheduledDate || null,
    s: b.startTime,
    e: b.endTime
  }));

  const today = new Date();
  const prompt = `Generate 3 study plans. Today: ${today.toISOString().split('T')[0]} (${["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][today.getDay()]})

BLOCKED TIMES (NEVER schedule during these):
- Sleep: ${settings.sleepStart}-${settings.sleepEnd}
- Lunch: 12:00-13:00
- Dinner: 17:30-19:00
- Max end time: 21:30 (no sessions after this)
- Earliest start: ${settings.preferredStartTime}

CLASSES (weekly recurring - check 'study' flag):
${JSON.stringify(compactClasses)}
IMPORTANT: "study: true" means Study Hall - this IS available time for work!
All OTHER classes are BLOCKED - never overlap sessions with regular classes.

EXISTING SCHEDULED BLOCKS (MUST NOT conflict):
${compactBlocks.length > 0 ? JSON.stringify(compactBlocks) : 'none'}
CRITICAL: Never schedule new sessions that overlap with existing blocks!

TASKS TO SCHEDULE (id, n=name, d=duration mins, dl=deadline, p=priority):
${JSON.stringify(compactTasks)}

CONFLICT AVOIDANCE RULES:
1. Before scheduling any session, verify it doesn't overlap with:
   - Regular classes (any class where study=false or study not present)
   - Existing scheduled blocks
   - Sleep, lunch, dinner times
2. Study Hall (study=true) is the ONLY exception - schedule work during Study Hall
3. Leave 10-15 minute buffers between sessions when possible
4. Sessions must be reasonable: 25-90 minutes each
5. Never exceed ${settings.maxWorkHours} hours of work per day
6. All sessions for a task must complete BEFORE its deadline

VALIDATION: For each session you create, mentally check:
- Does it overlap any regular class? If yes, MOVE IT.
- Does it overlap any existing block? If yes, MOVE IT.
- Is it during sleep/lunch/dinner? If yes, MOVE IT.
- Is it after 21:30? If yes, MOVE IT.

Return JSON:
{"overallAdvice":"...","weeklyGoals":["..."],"warnings":["..."],"planOptions":[{"id":"conservative|balanced|intensive","name":"...","description":"...","totalHours":N,"sessionsPerDay":{"Mon":N},"sessions":[{"taskId":"...","taskName":"...","dayOfWeek":N,"scheduledDate":"YYYY-MM-DD","startTime":"HH:MM","endTime":"HH:MM"}],"pros":["..."],"cons":["..."]}]}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "Expert study planner. Return valid JSON only. Never schedule during blocked times. Split tasks>90min. Cover full task duration."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4096,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    
    return {
      overallAdvice: parsed.overallAdvice || "Focus on your highest priority tasks first.",
      weeklyGoals: parsed.weeklyGoals || [],
      warnings: parsed.warnings || [],
      planOptions: parsed.planOptions || []
    };
  } catch (error: any) {
    console.error("Error generating study plan options:", error);
    
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    
    throw new Error("Failed to generate study plan options. Please try again.");
  }
}

// Keep the original function for backward compatibility
export async function generateStudyPlan(
  tasks: TaskToSchedule[],
  classes: ClassBlock[],
  settings: ScheduleSettings,
  scheduledBlocks: { dayOfWeek: number; startTime: string; endTime: string; isBreak: boolean }[]
): Promise<StudyPlan> {
  const prompt = `You are an expert academic advisor and productivity coach. Analyze the student's schedule, classes, and tasks to generate a personalized study plan with actionable recommendations.

STUDENT'S CLASS SCHEDULE (recurring weekly):
${JSON.stringify(classes, null, 2)}

TASKS/ASSIGNMENTS TO COMPLETE:
${JSON.stringify(tasks.map(t => ({
  id: t.id,
  name: t.name,
  durationMinutes: t.duration,
  deadline: t.deadline ? new Date(t.deadline).toISOString() : "No deadline",
  priority: t.priority,
  category: t.category
})), null, 2)}

CURRENT SCHEDULED BLOCKS:
${JSON.stringify(scheduledBlocks, null, 2)}

USER PREFERENCES:
- SLEEP SCHEDULE: ${settings.sleepStart} to ${settings.sleepEnd} - CRITICAL: NEVER recommend study times during these hours!
- DINNER TIME: 17:30 to 19:00 (5:30 PM - 7:00 PM) - Do NOT recommend study during dinner!
- Preferred work start: ${settings.preferredStartTime}
- Max work hours/day: ${settings.maxWorkHours}
- Break duration: ${settings.breakDuration} minutes

TODAY: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
TODAY'S DATE: ${new Date().toISOString().split('T')[0]}
CURRENT DAY OF WEEK: ${new Date().getDay()} (0=Sunday, 6=Saturday)

CRITICAL DEADLINE RULES:
1. Tasks with deadlines MUST be completed BEFORE the deadline date
2. If a task deadline is Dec 5, all work must be done by Dec 4
3. Prioritize tasks by: deadline proximity > priority level > duration
4. Add WARNINGS if any deadlines cannot be met

BLOCKED TIME - NEVER RECOMMEND STUDY DURING:
1. Sleep hours: ${settings.sleepStart} to ${settings.sleepEnd}
2. Dinner time: 17:30 to 19:00 (5:30 PM - 7:00 PM)
3. All "bestTimes" must avoid these blocked periods completely

STUDY HALL IS WORK TIME:
- "Study Hall" periods in the class schedule are IDEAL for completing homework
- Prioritize recommending Study Hall periods for task completion
- This is dedicated quiet time for focused work

ANALYZE AND PROVIDE:
1. For EACH task, determine:
   - Best times to work on it (respect blocked times, prefer Study Hall!)
   - Ensure all work is scheduled BEFORE the deadline
   - Whether it should be broken into smaller sessions
   - If breaking down, suggest how (e.g., "Split into 3 sessions of 45 minutes")
   - Why this priority order makes sense
   - Specific study tips for this type of task

2. Identify:
   - Overall productivity patterns and advice
   - Weekly goals the student should set
   - Any warnings about: impossible deadlines, scheduling conflicts, or overload
   - WARNING if any task deadline cannot be met

SCIENCE-BASED CONSIDERATIONS:
- Morning (after wake time): Best for complex analytical tasks
- Early afternoon (1-3pm): Good for creative work  
- Late afternoon (3-5pm): Good for collaborative work (but avoid 5:30-7pm dinner)
- Evening (after dinner, before bed): Light review only
- Study Hall periods: Ideal for focused homework and assignments
- Stop intense work at least 1 hour before bedtime
- Long tasks (>90 min) should be broken down (Pomodoro technique)
- Tasks with deadlines take priority over non-deadline tasks

Return a JSON object with this structure:
{
  "overallAdvice": "Brief personalized advice about the student's situation",
  "weeklyGoals": ["Goal 1", "Goal 2", "Goal 3"],
  "recommendations": [
    {
      "taskId": "uuid",
      "taskName": "Task name",
      "recommendations": {
        "bestTimes": ["Monday 9:00-10:30 AM", "Wednesday 2:00-3:30 PM"],
        "shouldBreakDown": true,
        "breakdownSuggestion": "Split into 3 sessions of 40 minutes each",
        "estimatedSessions": 3,
        "sessionDuration": 40,
        "priorityReason": "High priority with deadline in 3 days",
        "studyTips": ["Use active recall", "Take notes in your own words"]
      }
    }
  ],
  "warnings": ["Warning about any issues detected"]
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert academic advisor specializing in time management, study techniques, and productivity optimization. Provide science-based, actionable advice tailored to the student's specific situation. Always respond with valid JSON matching the exact structure requested."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 4096,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    
    return {
      overallAdvice: parsed.overallAdvice || "Focus on your highest priority tasks first.",
      weeklyGoals: parsed.weeklyGoals || [],
      recommendations: parsed.recommendations || [],
      warnings: parsed.warnings || []
    };
  } catch (error: any) {
    console.error("Error generating study plan:", error);
    
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    
    throw new Error("Failed to generate study plan. Please try again.");
  }
}

// Interface for parsed task from natural language
export interface ParsedTaskRequest {
  task: {
    name: string;
    duration: number; // in minutes
    priority: "low" | "medium" | "high" | "urgent";
    category: "school" | "workout" | "personal" | "health" | "other";
    notes: string | null;
    isRecurring: boolean;
    repeatDays: string[] | null; // ["0", "1", "2", "3", "4", "5", "6"]
    deadline: string | null; // ISO date string
  } | null;
  scheduling: {
    preferredTimeRange: { start: string; end: string } | null; // HH:MM format
    suggestedTime: string; // HH:MM format - AI's best recommendation
    reasoning: string;
  };
  response: string; // Friendly message to show the user
  understood: boolean; // Whether the AI understood the request
}

// Interface for parsed class/event from natural language
export interface ParsedClassRequest {
  classEntry: {
    name: string;
    dayOfWeek: number; // 0-6 (Sunday-Saturday)
    startTime: string; // HH:MM
    endTime: string; // HH:MM
    location: string | null;
    color: string | null; // hex color
  } | null;
  multipleClasses: {
    name: string;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    location: string | null;
    color: string | null;
  }[] | null; // For recurring classes on multiple days
  response: string;
  understood: boolean;
}

// Combined interface for AI assistant that can create tasks OR classes
export interface ParsedScheduleRequest {
  type: "task" | "class" | "both" | "unknown";
  task: ParsedTaskRequest["task"];
  classEntry: ParsedClassRequest["classEntry"];
  multipleClasses: ParsedClassRequest["multipleClasses"];
  scheduling: ParsedTaskRequest["scheduling"];
  response: string;
  understood: boolean;
}

export async function parseNaturalLanguageTask(
  userMessage: string,
  existingClasses: { name: string; dayOfWeek: number; startTime: string; endTime: string }[] = [],
  existingTasks: { name: string; isRecurring?: boolean; repeatDays?: string[] | null }[] = [],
  settings: { sleepStart: string; sleepEnd: string } = { sleepStart: "23:00", sleepEnd: "07:00" }
): Promise<ParsedTaskRequest> {
  
  const currentDate = new Date();
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const currentDayName = dayNames[currentDate.getDay()];
  
  const prompt = `You are a smart scheduling assistant. Parse the user's natural language request to create a task.

CURRENT CONTEXT:
- Today is ${currentDayName}, ${currentDate.toLocaleDateString()}
- User's sleep schedule: ${settings.sleepEnd} (wake) to ${settings.sleepStart} (sleep)
- Existing classes: ${existingClasses.length > 0 ? existingClasses.map(c => `${c.name} on ${dayNames[c.dayOfWeek]} ${c.startTime}-${c.endTime}`).join(", ") : "None"}
- Existing tasks: ${existingTasks.length > 0 ? existingTasks.map(t => t.name).join(", ") : "None"}

USER REQUEST: "${userMessage}"

TASK TYPES & COMMON-SENSE SCHEDULING RULES:
1. **Personal hygiene (shower, brushing teeth, skincare)**:
   - Shower: Schedule in morning (6-8 AM) or evening (7-10 PM), NEVER during work/school hours or midday
   - Duration: typically 15-30 minutes
   - Category: health or personal
   
2. **Meals (breakfast, lunch, dinner)**:
   - Breakfast: 6:30-9:00 AM
   - Lunch: 11:30 AM - 1:30 PM
   - Dinner: 5:30-8:00 PM
   - Duration: 20-45 minutes
   - Category: health
   
3. **Exercise/Workout**:
   - Best times: Morning (6-8 AM) or evening (5-8 PM)
   - Avoid right after meals (wait 1-2 hours)
   - Duration: 30-90 minutes typically
   - Category: workout
   
4. **Sleep/Rest/Nap**:
   - Naps: Midday (1-3 PM), 20-30 minutes
   - Bedtime routine: 30-60 minutes before sleep time
   - Category: health
   
5. **Study/Homework**:
   - Best during awake hours, avoid late night
   - Category: school
   
6. **Personal/Recreation**:
   - Flexible timing but avoid conflicts with other activities
   - Category: personal

PARSING INSTRUCTIONS:
1. Extract the task name from the request
2. Determine if it's recurring (daily, every day, weekdays, etc.) or one-time
3. If recurring, identify which days (0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat)
4. If user provides a time range, use it; otherwise suggest based on common sense
5. Estimate appropriate duration based on task type
6. Assign priority based on importance and urgency
7. Provide a friendly, helpful response message

TIME RANGE INTERPRETATION:
- "between 6pm to 11pm" → preferredTimeRange: { start: "18:00", end: "23:00" }
- "in the morning" → preferredTimeRange: { start: "06:00", end: "12:00" }
- "evening" → preferredTimeRange: { start: "17:00", end: "22:00" }
- "after dinner" → preferredTimeRange: { start: "19:30", end: "22:00" }

RECURRING PATTERNS:
- "everyday" or "daily" → repeatDays: ["0","1","2","3","4","5","6"], isRecurring: true
- "weekdays" → repeatDays: ["1","2","3","4","5"], isRecurring: true
- "weekends" → repeatDays: ["0","6"], isRecurring: true
- "every Monday and Wednesday" → repeatDays: ["1","3"], isRecurring: true
- No recurring pattern mentioned → isRecurring: false, repeatDays: null

Return a JSON object with this exact structure:
{
  "task": {
    "name": "Shower",
    "duration": 20,
    "priority": "medium",
    "category": "health",
    "notes": null,
    "isRecurring": true,
    "repeatDays": ["0","1","2","3","4","5","6"],
    "deadline": null
  },
  "scheduling": {
    "preferredTimeRange": { "start": "18:00", "end": "23:00" },
    "suggestedTime": "20:00",
    "reasoning": "Evening shower at 8 PM is ideal - after dinner and before bedtime"
  },
  "response": "I've created a daily shower task scheduled for 8:00 PM. This time works well as it's after dinner and gives you time to relax before bed.",
  "understood": true
}

If you cannot understand the request, set understood: false and provide a helpful response asking for clarification.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a smart scheduling assistant that helps users create tasks from natural language. Always respond with valid JSON. Apply common sense to schedule tasks at appropriate times."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1024,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    
    return {
      task: {
        name: parsed.task?.name || "New Task",
        duration: parsed.task?.duration || 30,
        priority: parsed.task?.priority || "medium",
        category: parsed.task?.category || "personal",
        notes: parsed.task?.notes || null,
        isRecurring: parsed.task?.isRecurring || false,
        repeatDays: parsed.task?.repeatDays || null,
        deadline: parsed.task?.deadline || null,
      },
      scheduling: {
        preferredTimeRange: parsed.scheduling?.preferredTimeRange || null,
        suggestedTime: parsed.scheduling?.suggestedTime || "09:00",
        reasoning: parsed.scheduling?.reasoning || "Scheduled at a reasonable time.",
      },
      response: parsed.response || "I've created your task.",
      understood: parsed.understood !== false,
    };
  } catch (error: any) {
    console.error("Error parsing natural language task:", error);
    
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    
    throw new Error("Failed to understand your request. Please try again with more details.");
  }
}

// Enhanced function that can parse both tasks AND classes from natural language
export async function parseNaturalLanguageRequest(
  userMessage: string,
  existingClasses: { name: string; dayOfWeek: number; startTime: string; endTime: string }[] = [],
  existingTasks: { name: string; isRecurring?: boolean; repeatDays?: string[] | null }[] = [],
  settings: { sleepStart: string; sleepEnd: string } = { sleepStart: "23:00", sleepEnd: "07:00" }
): Promise<ParsedScheduleRequest> {
  
  const currentDate = new Date();
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const currentDayName = dayNames[currentDate.getDay()];
  
  const prompt = `You are a smart scheduling assistant. Parse the user's request and determine if they want to create:
1. A TASK (something to be done/completed, like homework, exercise, chores)
2. A CLASS/EVENT (a recurring scheduled block like a course, meeting, work shift)
3. BOTH (e.g., "add my Chemistry class on MWF 9-10am and remind me to study for it")

CURRENT CONTEXT:
- Today is ${currentDayName}, ${currentDate.toLocaleDateString()}
- User's sleep schedule: ${settings.sleepEnd} (wake) to ${settings.sleepStart} (sleep)
- Existing classes: ${existingClasses.length > 0 ? existingClasses.map(c => c.name + " on " + dayNames[c.dayOfWeek] + " " + c.startTime + "-" + c.endTime).join(", ") : "None"}
- Existing tasks: ${existingTasks.length > 0 ? existingTasks.map(t => t.name).join(", ") : "None"}

USER REQUEST: "${userMessage}"

HOW TO IDENTIFY CLASSES vs TASKS:
- CLASSES: Fixed time slots that repeat weekly (courses, lectures, labs, meetings, work shifts, gym classes)
  - Keywords: "class", "course", "lecture", "lab", "meeting", "work shift", "office hours"
  - Usually have specific days and times: "MWF 9-10am", "every Tuesday 2-3:30pm"
  - Don't have deadlines (they're recurring events)
  
- TASKS: Things to complete (homework, assignments, chores, errands, workouts)
  - Keywords: "need to", "have to", "should", "want to", "remind me to"
  - May have deadlines: "due Friday", "by tomorrow"
  - May be recurring: "shower daily", "exercise every weekday"

PARSING CLASSES - CRITICAL RULES:
- Extract: name, dayOfWeek (0-6), startTime (HH:MM in 24h format), endTime (HH:MM), location (optional)
- IMPORTANT: If multiple days are mentioned, you MUST create SEPARATE entries in multipleClasses for EACH day
- Day mapping: Sunday=0, Monday=1, Tuesday=2, Wednesday=3, Thursday=4, Friday=5, Saturday=6
- Common abbreviations: M=Monday(1), T=Tuesday(2), W=Wednesday(3), R/Th=Thursday(4), F=Friday(5), S/Sa=Saturday(6), Su=Sunday(0)
- MWF = Monday, Wednesday, Friday = create 3 entries with dayOfWeek: 1, 3, 5
- TTh = Tuesday, Thursday = create 2 entries with dayOfWeek: 2, 4
- "Monday and Wednesday" = create 2 entries with dayOfWeek: 1, 3
- Always use 24-hour time format: 2pm = 14:00, 9am = 09:00

PARSING TASKS:
- Same rules as before for tasks (duration, priority, category, recurring, deadline)
- If user mentions both a class AND a task (like "add my Math class and remind me to do homework"), create both

TASK CATEGORIES & COMMON-SENSE SCHEDULING:
1. Personal hygiene: health/personal, morning or evening
2. Meals: health, appropriate meal times
3. Exercise/Workout: workout category
4. Study/Homework: school category
5. Personal/Recreation: personal category

Return a JSON object with this structure:
{
  "type": "task" | "class" | "both" | "unknown",
  "task": {  // null if not creating a task
    "name": "string",
    "duration": number,
    "priority": "low"|"medium"|"high"|"urgent",
    "category": "school"|"workout"|"personal"|"health"|"other",
    "notes": "string or null",
    "isRecurring": boolean,
    "repeatDays": ["0","1","2"...] or null,
    "deadline": "ISO date string" or null
  },
  "classEntry": {  // null if single class (use multipleClasses) or not creating a class
    "name": "string",
    "dayOfWeek": number,
    "startTime": "HH:MM",
    "endTime": "HH:MM",
    "location": "string or null",
    "color": "#hex or null"
  },
  "multipleClasses": [  // array of classes if same class on multiple days, null otherwise
    {
      "name": "string",
      "dayOfWeek": number,
      "startTime": "HH:MM",
      "endTime": "HH:MM",
      "location": "string or null",
      "color": "#hex or null"
    }
  ],
  "scheduling": {
    "preferredTimeRange": { "start": "HH:MM", "end": "HH:MM" } or null,
    "suggestedTime": "HH:MM",
    "reasoning": "string"
  },
  "response": "Friendly confirmation message",
  "understood": true
}

EXAMPLES (you MUST follow these patterns exactly):

1. "Add my Chemistry class MWF 9-10am in Room 201"
   Response: {
     "type": "class",
     "task": null,
     "classEntry": null,
     "multipleClasses": [
       {"name":"Chemistry", "dayOfWeek":1, "startTime":"09:00", "endTime":"10:00", "location":"Room 201", "color":"#3b82f6"},
       {"name":"Chemistry", "dayOfWeek":3, "startTime":"09:00", "endTime":"10:00", "location":"Room 201", "color":"#3b82f6"},
       {"name":"Chemistry", "dayOfWeek":5, "startTime":"09:00", "endTime":"10:00", "location":"Room 201", "color":"#3b82f6"}
     ],
     "scheduling": {"preferredTimeRange":null, "suggestedTime":"09:00", "reasoning":"Class is at 9 AM"},
     "response": "I've added your Chemistry class for Monday, Wednesday, and Friday from 9-10 AM in Room 201.",
     "understood": true
   }

2. "Add my Physics class on Monday and Wednesday 2-3pm"
   Response: {
     "type": "class",
     "task": null,
     "classEntry": null,
     "multipleClasses": [
       {"name":"Physics", "dayOfWeek":1, "startTime":"14:00", "endTime":"15:00", "location":null, "color":"#3b82f6"},
       {"name":"Physics", "dayOfWeek":3, "startTime":"14:00", "endTime":"15:00", "location":null, "color":"#3b82f6"}
     ],
     "scheduling": {"preferredTimeRange":null, "suggestedTime":"14:00", "reasoning":"Class is at 2 PM"},
     "response": "I've added your Physics class for Monday and Wednesday from 2-3 PM.",
     "understood": true
   }

3. "I need to shower every day between 7-9pm"
   Response: {"type":"task", "task":{"name":"Shower","duration":20,"priority":"medium","category":"health","notes":null,"isRecurring":true,"repeatDays":["0","1","2","3","4","5","6"],"deadline":null}, "classEntry":null, "multipleClasses":null, ...}

4. "Add my work shift Tuesday and Thursday 2-6pm"
   Response: {
     "type": "class",
     "task": null,
     "classEntry": null,
     "multipleClasses": [
       {"name":"Work shift", "dayOfWeek":2, "startTime":"14:00", "endTime":"18:00", "location":null, "color":"#3b82f6"},
       {"name":"Work shift", "dayOfWeek":4, "startTime":"14:00", "endTime":"18:00", "location":null, "color":"#3b82f6"}
     ],
     ...
   }

If you cannot understand the request, set understood: false and provide a helpful response.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a smart scheduling assistant that helps users create tasks and classes from natural language. Always respond with valid JSON. Determine whether the user wants to add a task, a class/event, or both, and parse accordingly."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 2048,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    
    return {
      type: parsed.type || "unknown",
      task: parsed.task ? {
        name: parsed.task.name || "New Task",
        duration: parsed.task.duration || 30,
        priority: parsed.task.priority || "medium",
        category: parsed.task.category || "personal",
        notes: parsed.task.notes || null,
        isRecurring: parsed.task.isRecurring || false,
        repeatDays: parsed.task.repeatDays || null,
        deadline: parsed.task.deadline || null,
      } : null,
      classEntry: parsed.classEntry || null,
      multipleClasses: parsed.multipleClasses || null,
      scheduling: {
        preferredTimeRange: parsed.scheduling?.preferredTimeRange || null,
        suggestedTime: parsed.scheduling?.suggestedTime || "09:00",
        reasoning: parsed.scheduling?.reasoning || "Scheduled at a reasonable time.",
      },
      response: parsed.response || "I've processed your request.",
      understood: parsed.understood !== false,
    };
  } catch (error: any) {
    console.error("Error parsing natural language request:", error);
    
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      throw new Error("AI service is temporarily busy. Please wait a moment and try again.");
    }
    if (error?.status === 401) {
      throw new Error("AI service authentication failed. Please try refreshing the page.");
    }
    
    throw new Error("Failed to understand your request. Please try again with more details.");
  }
}
