import { google } from 'googleapis';
import crypto from 'crypto';
import { storage } from './storage';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

// Use REPLIT_DEV_DOMAIN for development, or construct from deployment URL
function getRedirectUri(): string {
  // Check for explicit override first
  if (process.env.GOOGLE_REDIRECT_URI) {
    return process.env.GOOGLE_REDIRECT_URI;
  }
  
  // Use REPLIT_DEV_DOMAIN for development environment (recommended by Replit)
  if (process.env.REPLIT_DEV_DOMAIN) {
    return `https://${process.env.REPLIT_DEV_DOMAIN}/api/auth/google/callback`;
  }
  
  // Fallback to older environment variables
  if (process.env.REPL_SLUG && process.env.REPL_OWNER) {
    return `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co/api/auth/google/callback`;
  }
  
  // Local development fallback
  return 'http://localhost:5000/api/auth/google/callback';
}

const GOOGLE_REDIRECT_URI = getRedirectUri();

const SCOPES = [
  'https://www.googleapis.com/auth/calendar.readonly',
  'https://www.googleapis.com/auth/userinfo.email'
];

const pendingStates = new Map<string, { createdAt: number }>();

function cleanupOldStates() {
  const now = Date.now();
  const keysToDelete: string[] = [];
  pendingStates.forEach((data, state) => {
    if (now - data.createdAt > 10 * 60 * 1000) {
      keysToDelete.push(state);
    }
  });
  keysToDelete.forEach(state => pendingStates.delete(state));
}

function createOAuth2Client() {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
    throw new Error('Google OAuth credentials not configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.');
  }
  
  return new google.auth.OAuth2(
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI
  );
}

export function getGoogleAuthUrl(): { url: string; state: string } {
  cleanupOldStates();
  
  const oauth2Client = createOAuth2Client();
  
  const state = crypto.randomBytes(32).toString('hex');
  pendingStates.set(state, { createdAt: Date.now() });
  
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent',
    state,
  });
  
  return { url, state };
}

export function validateOAuthState(state: string): boolean {
  if (!pendingStates.has(state)) {
    return false;
  }
  pendingStates.delete(state);
  return true;
}

export async function exchangeCodeForTokens(code: string): Promise<{
  accessToken: string;
  refreshToken: string | null;
  expiresAt: Date | null;
  email: string | null;
}> {
  const oauth2Client = createOAuth2Client();
  
  const { tokens } = await oauth2Client.getToken(code);
  oauth2Client.setCredentials(tokens);
  
  let email: string | null = null;
  try {
    const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
    const userInfo = await oauth2.userinfo.get();
    email = userInfo.data.email || null;
  } catch (e) {
    console.error('Failed to get user email:', e);
  }
  
  return {
    accessToken: tokens.access_token || '',
    refreshToken: tokens.refresh_token || null,
    expiresAt: tokens.expiry_date ? new Date(tokens.expiry_date) : null,
    email
  };
}

async function getValidAccessToken(userId: string): Promise<string> {
  const storedTokens = await storage.getGoogleTokens(userId);
  
  if (!storedTokens) {
    throw new Error('Google Calendar not connected. Please connect your account first.');
  }
  
  if (storedTokens.expiresAt && new Date(storedTokens.expiresAt).getTime() > Date.now() + 5 * 60 * 1000) {
    return storedTokens.accessToken;
  }
  
  if (!storedTokens.refreshToken) {
    throw new Error('Cannot refresh token - no refresh token available. Please reconnect your Google Calendar.');
  }
  
  const oauth2Client = createOAuth2Client();
  oauth2Client.setCredentials({
    refresh_token: storedTokens.refreshToken
  });
  
  try {
    const { credentials } = await oauth2Client.refreshAccessToken();
    
    await storage.saveGoogleTokens({
      userId,
      accessToken: credentials.access_token || storedTokens.accessToken,
      refreshToken: credentials.refresh_token || storedTokens.refreshToken,
      expiresAt: credentials.expiry_date ? new Date(credentials.expiry_date) : null,
      email: storedTokens.email
    });
    
    return credentials.access_token || storedTokens.accessToken;
  } catch (error) {
    console.error('Failed to refresh token:', error);
    throw new Error('Failed to refresh Google Calendar access. Please reconnect your account.');
  }
}

async function getGoogleCalendarClient(userId: string) {
  const accessToken = await getValidAccessToken(userId);
  
  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({ access_token: accessToken });
  
  return google.calendar({ version: 'v3', auth: oauth2Client });
}

export interface ParsedClassEntry {
  name: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  location?: string;
}

function parseTimeToHHMM(dateTime: string | null | undefined, date: string | null | undefined): string {
  if (dateTime) {
    const d = new Date(dateTime);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  }
  return "00:00";
}

function getDayOfWeekFromDate(dateTime: string | null | undefined, date: string | null | undefined): number {
  if (dateTime) {
    return new Date(dateTime).getDay();
  }
  if (date) {
    return new Date(date).getDay();
  }
  return 0;
}

export async function checkGoogleCalendarConnection(userId: string): Promise<{ 
  connected: boolean; 
  email?: string;
  needsCredentials?: boolean;
}> {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
    return { connected: false, needsCredentials: true };
  }
  
  try {
    const tokens = await storage.getGoogleTokens(userId);
    if (!tokens) {
      return { connected: false };
    }
    
    await getValidAccessToken(userId);
    return { connected: true, email: tokens.email || undefined };
  } catch {
    return { connected: false };
  }
}

export async function disconnectGoogleCalendar(userId: string): Promise<void> {
  await storage.deleteGoogleTokens(userId);
}

export async function listGoogleCalendars(userId: string): Promise<{ id: string; summary: string; primary?: boolean }[]> {
  const calendar = await getGoogleCalendarClient(userId);
  
  const response = await calendar.calendarList.list();
  
  return (response.data.items || []).map(cal => ({
    id: cal.id || '',
    summary: cal.summary || 'Unnamed Calendar',
    primary: cal.primary || false
  }));
}

export async function importEventsFromGoogleCalendar(
  userId: string,
  calendarId: string = 'primary',
  daysAhead: number = 30
): Promise<ParsedClassEntry[]> {
  const calendar = await getGoogleCalendarClient(userId);
  
  const now = new Date();
  const timeMin = now.toISOString();
  const timeMax = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000).toISOString();
  
  const response = await calendar.events.list({
    calendarId,
    timeMin,
    timeMax,
    singleEvents: true,
    orderBy: 'startTime',
    maxResults: 250
  });
  
  const events = response.data.items || [];
  const classEntries: ParsedClassEntry[] = [];
  const seenEvents = new Map<string, ParsedClassEntry>();
  
  for (const event of events) {
    if (!event.summary) continue;
    
    const startDateTime = event.start?.dateTime;
    const endDateTime = event.end?.dateTime;
    const startDate = event.start?.date;
    const endDate = event.end?.date;
    
    if (!startDateTime && !startDate) continue;
    
    const dayOfWeek = getDayOfWeekFromDate(startDateTime, startDate);
    const startTime = parseTimeToHHMM(startDateTime, startDate);
    const endTime = parseTimeToHHMM(endDateTime, endDate);
    
    const key = `${event.summary}-${dayOfWeek}-${startTime}-${endTime}`;
    
    if (!seenEvents.has(key)) {
      const entry: ParsedClassEntry = {
        name: event.summary,
        dayOfWeek,
        startTime,
        endTime,
        location: event.location || undefined
      };
      seenEvents.set(key, entry);
      classEntries.push(entry);
    }
  }
  
  return classEntries;
}
