import { 
  users, type User, type UpsertUser,
  classEntries, type ClassEntry, type InsertClassEntry,
  tasks, type Task, type InsertTask,
  scheduledBlocks, type ScheduledBlock, type InsertScheduledBlock,
  userSettings, type UserSettings, type InsertUserSettings,
  googleTokens, type GoogleTokens, type InsertGoogleTokens,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Users (for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Class Entries - per user (all operations require userId)
  getAllClasses(userId: string): Promise<ClassEntry[]>;
  getClass(userId: string, id: string): Promise<ClassEntry | undefined>;
  createClass(entry: InsertClassEntry): Promise<ClassEntry>;
  createClassesBulk(entries: InsertClassEntry[]): Promise<ClassEntry[]>;
  updateClass(userId: string, id: string, updates: Partial<ClassEntry>): Promise<ClassEntry | undefined>;
  deleteClass(userId: string, id: string): Promise<void>;
  deleteAllClasses(userId: string): Promise<void>;
  
  // Tasks - per user (all operations require userId)
  getAllTasks(userId: string): Promise<Task[]>;
  getTask(userId: string, id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(userId: string, id: string, updates: Partial<Task>): Promise<Task | undefined>;
  deleteTask(userId: string, id: string): Promise<void>;
  
  // Scheduled Blocks - per user (all operations require userId)
  getAllScheduledBlocks(userId: string): Promise<ScheduledBlock[]>;
  getScheduledBlock(userId: string, id: string): Promise<ScheduledBlock | undefined>;
  createScheduledBlock(block: InsertScheduledBlock): Promise<ScheduledBlock>;
  createScheduledBlocksBulk(blocks: InsertScheduledBlock[]): Promise<ScheduledBlock[]>;
  updateScheduledBlock(userId: string, id: string, updates: Partial<ScheduledBlock>): Promise<ScheduledBlock | undefined>;
  deleteScheduledBlock(userId: string, id: string): Promise<void>;
  deleteAllScheduledBlocks(userId: string): Promise<void>;
  
  // User Settings - per user
  getSettings(userId: string): Promise<UserSettings | undefined>;
  upsertSettings(settings: InsertUserSettings): Promise<UserSettings>;
  
  // Google OAuth Tokens - per user
  getGoogleTokens(userId: string): Promise<GoogleTokens | undefined>;
  saveGoogleTokens(tokens: InsertGoogleTokens): Promise<GoogleTokens>;
  deleteGoogleTokens(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users (for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Class Entries - per user (all operations scoped by userId)
  async getAllClasses(userId: string): Promise<ClassEntry[]> {
    return db.select().from(classEntries).where(eq(classEntries.userId, userId));
  }

  async getClass(userId: string, id: string): Promise<ClassEntry | undefined> {
    const [entry] = await db.select().from(classEntries).where(
      and(eq(classEntries.id, id), eq(classEntries.userId, userId))
    );
    return entry || undefined;
  }

  async createClass(entry: InsertClassEntry): Promise<ClassEntry> {
    const [created] = await db.insert(classEntries).values(entry).returning();
    return created;
  }

  async createClassesBulk(entries: InsertClassEntry[]): Promise<ClassEntry[]> {
    if (entries.length === 0) return [];
    return db.insert(classEntries).values(entries).returning();
  }

  async updateClass(userId: string, id: string, updates: Partial<ClassEntry>): Promise<ClassEntry | undefined> {
    const [updated] = await db
      .update(classEntries)
      .set(updates)
      .where(and(eq(classEntries.id, id), eq(classEntries.userId, userId)))
      .returning();
    return updated || undefined;
  }

  async deleteClass(userId: string, id: string): Promise<void> {
    await db.delete(classEntries).where(
      and(eq(classEntries.id, id), eq(classEntries.userId, userId))
    );
  }

  async deleteAllClasses(userId: string): Promise<void> {
    await db.delete(classEntries).where(eq(classEntries.userId, userId));
  }

  // Tasks - per user (all operations scoped by userId)
  async getAllTasks(userId: string): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.userId, userId));
  }

  async getTask(userId: string, id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(
      and(eq(tasks.id, id), eq(tasks.userId, userId))
    );
    return task || undefined;
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [created] = await db.insert(tasks).values(task).returning();
    return created;
  }

  async updateTask(userId: string, id: string, updates: Partial<Task>): Promise<Task | undefined> {
    const [updated] = await db
      .update(tasks)
      .set(updates)
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    return updated || undefined;
  }

  async deleteTask(userId: string, id: string): Promise<void> {
    await db.delete(tasks).where(
      and(eq(tasks.id, id), eq(tasks.userId, userId))
    );
  }

  // Scheduled Blocks - per user (all operations scoped by userId)
  async getAllScheduledBlocks(userId: string): Promise<ScheduledBlock[]> {
    return db.select().from(scheduledBlocks).where(eq(scheduledBlocks.userId, userId));
  }

  async getScheduledBlock(userId: string, id: string): Promise<ScheduledBlock | undefined> {
    const [block] = await db.select().from(scheduledBlocks).where(
      and(eq(scheduledBlocks.id, id), eq(scheduledBlocks.userId, userId))
    );
    return block || undefined;
  }

  async createScheduledBlock(block: InsertScheduledBlock): Promise<ScheduledBlock> {
    const [created] = await db.insert(scheduledBlocks).values(block).returning();
    return created;
  }

  async createScheduledBlocksBulk(blocks: InsertScheduledBlock[]): Promise<ScheduledBlock[]> {
    if (blocks.length === 0) return [];
    return db.insert(scheduledBlocks).values(blocks).returning();
  }

  async updateScheduledBlock(userId: string, id: string, updates: Partial<ScheduledBlock>): Promise<ScheduledBlock | undefined> {
    const [updated] = await db
      .update(scheduledBlocks)
      .set(updates)
      .where(and(eq(scheduledBlocks.id, id), eq(scheduledBlocks.userId, userId)))
      .returning();
    return updated || undefined;
  }

  async deleteScheduledBlock(userId: string, id: string): Promise<void> {
    await db.delete(scheduledBlocks).where(
      and(eq(scheduledBlocks.id, id), eq(scheduledBlocks.userId, userId))
    );
  }

  async deleteAllScheduledBlocks(userId: string): Promise<void> {
    await db.delete(scheduledBlocks).where(eq(scheduledBlocks.userId, userId));
  }

  // User Settings - per user
  async getSettings(userId: string): Promise<UserSettings | undefined> {
    const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    return settings || undefined;
  }

  async upsertSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const existing = settings.userId ? await this.getSettings(settings.userId) : undefined;
    if (existing) {
      const [updated] = await db
        .update(userSettings)
        .set(settings)
        .where(eq(userSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(userSettings).values(settings).returning();
      return created;
    }
  }

  // Google OAuth Tokens - per user
  async getGoogleTokens(userId: string): Promise<GoogleTokens | undefined> {
    const [tokens] = await db.select().from(googleTokens).where(eq(googleTokens.userId, userId));
    return tokens || undefined;
  }

  async saveGoogleTokens(tokens: InsertGoogleTokens): Promise<GoogleTokens> {
    // Delete existing tokens for this user first
    await db.delete(googleTokens).where(eq(googleTokens.userId, tokens.userId));
    const [created] = await db.insert(googleTokens).values(tokens).returning();
    return created;
  }

  async deleteGoogleTokens(userId: string): Promise<void> {
    await db.delete(googleTokens).where(eq(googleTokens.userId, userId));
  }
}

export const storage = new DatabaseStorage();
