import { StudyPlanPanel } from "@/components/StudyPlanPanel";

export default function StudyPlan() {
  return <StudyPlanPanel />;
}
