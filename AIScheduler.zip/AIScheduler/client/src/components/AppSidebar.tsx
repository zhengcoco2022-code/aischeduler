import { useLocation, Link } from "wouter";
import {
  Calendar,
  LayoutDashboard,
  ListTodo,
  Upload,
  Settings,
  Clock,
  Brain,
  MessageCircle,
  Loader2,
  CheckCircle,
  Link2,
  Unlink,
  AlertCircle,
  LogOut,
  User,
} from "lucide-react";
import { SiGooglecalendar } from "react-icons/si";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";

interface GoogleCalendarStatus {
  connected: boolean;
  email?: string;
  error?: string;
  needsCredentials?: boolean;
}

const menuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Weekly Schedule",
    url: "/schedule",
    icon: Calendar,
  },
  {
    title: "Upload Schedule",
    url: "/upload",
    icon: Upload,
  },
  {
    title: "Tasks",
    url: "/tasks",
    icon: ListTodo,
  },
  {
    title: "AI Assistant",
    url: "/chat",
    icon: MessageCircle,
  },
  {
    title: "Study Plan",
    url: "/study-plan",
    icon: Brain,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  // Query Google Calendar connection status
  const { data: googleStatus, isLoading: isLoadingStatus } =
    useQuery<GoogleCalendarStatus>({
      queryKey: ["/api/google-calendar/status"],
    });

  // Connect to Google Calendar
  const connectMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/auth/google");
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to get authorization URL");
      }
      return response.json();
    },
    onSuccess: (data: { authUrl: string }) => {
      window.location.href = data.authUrl;
    },
    onError: (error: Error) => {
      toast({
        title: "Connection failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Disconnect from Google Calendar
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/google-calendar/disconnect", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/google-calendar/status"],
      });
      toast({
        title: "Disconnected",
        description: "Google Calendar has been disconnected.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Disconnect failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Sidebar>
      <SidebarHeader className="p-6">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <Clock className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-semibold" data-testid="text-app-name">
              SmartSchedule
            </span>
            <span className="text-xs text-muted-foreground">
              AI-Powered Planning
            </span>
          </div>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link
                      href={item.url}
                      data-testid={`link-nav-${item.title.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 space-y-3">
        {user && (
          <div className="rounded-lg bg-muted p-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                {user.profileImageUrl && (
                  <AvatarImage
                    src={user.profileImageUrl}
                    alt={user.firstName || "User"}
                  />
                )}
                <AvatarFallback>
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p
                  className="text-sm font-medium truncate"
                  data-testid="text-user-name"
                >
                  {user.firstName || user.email?.split("@")[0] || "User"}
                </p>
                <p
                  className="text-xs text-muted-foreground truncate"
                  title={user.email || ""}
                >
                  {user.email}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="w-full mt-2"
              asChild
              data-testid="button-logout"
            >
              <a href="/api/logout">
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </a>
            </Button>
          </div>
        )}
        <div className="rounded-lg bg-muted p-4 space-y-3">
          <div className="flex items-center gap-2">
            <SiGooglecalendar className="h-4 w-4 text-blue-500" />
            <span className="text-sm font-medium">Google Calendar</span>
          </div>
          {isLoadingStatus ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Checking...</span>
            </div>
          ) : googleStatus?.needsCredentials ? (
            <>
              <div className="flex items-center gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-yellow-500" />
                <span className="text-muted-foreground">Setup Required</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Google OAuth credentials need to be configured.
              </p>
            </>
          ) : googleStatus?.connected ? (
            <>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span
                  className="text-muted-foreground truncate"
                  title={googleStatus.email}
                >
                  {googleStatus.email
                    ? `${googleStatus.email.split("@")[0]}@...`
                    : "Connected"}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => disconnectMutation.mutate()}
                disabled={disconnectMutation.isPending}
                data-testid="button-disconnect-google-sidebar"
              >
                {disconnectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Unlink className="h-4 w-4 mr-2" />
                )}
                Disconnect
              </Button>
            </>
          ) : (
            <>
              <p className="text-xs text-muted-foreground">
                Connect your Google account to import calendar events.
              </p>
              <Button
                size="sm"
                className="w-full"
                onClick={() => connectMutation.mutate()}
                disabled={connectMutation.isPending}
                data-testid="button-connect-google-sidebar"
              >
                {connectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Link2 className="h-4 w-4 mr-2" />
                )}
                Connect Google Calendar
              </Button>
            </>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
