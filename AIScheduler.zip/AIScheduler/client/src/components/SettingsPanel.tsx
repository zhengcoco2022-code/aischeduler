import { useEffect } from "react";
import { Loader2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { UserSettings } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";

const settingsSchema = z.object({
  sleepStart: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  sleepEnd: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  breakDuration: z.coerce.number().min(5).max(60),
  maxWorkHours: z.coerce.number().min(1).max(16),
  preferredStartTime: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export function SettingsPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      sleepStart: "23:00",
      sleepEnd: "07:00",
      breakDuration: 15,
      maxWorkHours: 8,
      preferredStartTime: "08:00",
    },
  });

  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        sleepStart: settings.sleepStart || "23:00",
        sleepEnd: settings.sleepEnd || "07:00",
        breakDuration: settings.breakDuration || 15,
        maxWorkHours: settings.maxWorkHours || 8,
        preferredStartTime: settings.preferredStartTime || "08:00",
      });
    }
  }, [settings, form]);

  const saveMutation = useMutation({
    mutationFn: async (data: SettingsFormData) => {
      return apiRequest("PUT", "/api/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings saved",
        description: "Your preferences have been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SettingsFormData) => {
    saveMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-12">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Schedule Settings</CardTitle>
        <CardDescription>
          Configure your preferences for the AI scheduling engine. These settings help create a healthy, realistic schedule.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="sleepStart"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sleep Start Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        {...field}
                        data-testid="input-sleep-start"
                      />
                    </FormControl>
                    <FormDescription>
                      When you typically go to bed
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sleepEnd"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Wake Up Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        {...field}
                        data-testid="input-sleep-end"
                      />
                    </FormControl>
                    <FormDescription>
                      When you typically wake up
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="preferredStartTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Start Time</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        {...field}
                        data-testid="input-preferred-start"
                      />
                    </FormControl>
                    <FormDescription>
                      When you prefer to start scheduling tasks
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="maxWorkHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Max Work Hours Per Day</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1}
                        max={16}
                        {...field}
                        data-testid="input-max-work-hours"
                      />
                    </FormControl>
                    <FormDescription>
                      Maximum hours of tasks per day
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="breakDuration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Break Duration (minutes)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={5}
                        max={60}
                        step={5}
                        {...field}
                        data-testid="input-break-duration"
                      />
                    </FormControl>
                    <FormDescription>
                      Duration of automatic breaks between tasks
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={saveMutation.isPending}
                data-testid="button-save-settings"
              >
                {saveMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Settings
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
