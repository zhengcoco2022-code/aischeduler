import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Loader2, Sparkles, CheckCircle, Calendar, BookOpen, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Task, ClassEntry } from "@shared/schema";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  task?: Task;
  classes?: ClassEntry[];
  scheduling?: {
    preferredTimeRange: { start: string; end: string } | null;
    suggestedTime: string;
    reasoning: string;
  };
}

interface ChatResponse {
  success: boolean;
  type?: "task" | "class" | "both" | "unknown";
  response: string;
  task?: Task;
  classes?: ClassEntry[];
  scheduling?: {
    preferredTimeRange: { start: string; end: string } | null;
    suggestedTime: string;
    reasoning: string;
  };
  message?: string;
}

const EXAMPLE_PROMPTS = [
  "Add my Math class MWF 9-10am in Room 101",
  "I need to shower every day between 7-10 PM",
  "Schedule my Chemistry lab TTh 2-4pm",
  "Add a 30 minute workout on weekdays at 6 AM",
  "Add my work shift Tuesday and Thursday 5-9pm",
];

export function AIChatBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hi! I'm your AI scheduling assistant. I can add both classes and tasks to your schedule. Try:\n\n- \"Add my Math class MWF 9-10am\"\n- \"I need to shower daily between 7-10pm\"\n- \"Schedule my work shift TTh 2-6pm\"",
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const chatMutation = useMutation({
    mutationFn: async (message: string): Promise<ChatResponse> => {
      const response = await apiRequest("POST", "/api/chat/task", { message });
      return response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: ChatMessage = {
        id: Date.now().toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
        task: data.task || undefined,
        classes: data.classes || undefined,
        scheduling: data.scheduling,
      };
      setMessages(prev => [...prev, assistantMessage]);
      
      if (data.success) {
        // Invalidate caches so they refetch with fresh data
        // WeeklyCalendar uses staleTime: 0 so it will always refetch on mount
        if (data.task) {
          queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
          queryClient.invalidateQueries({ queryKey: ["/api/schedule/health"] });
        }
        if (data.classes && data.classes.length > 0) {
          queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
          queryClient.invalidateQueries({ queryKey: ["/api/schedule/health"] });
        }
        
        // Show appropriate toast
        if (data.task && data.classes && data.classes.length > 0) {
          toast({
            title: "Created!",
            description: `Added "${data.task.name}" and ${data.classes.length} class${data.classes.length > 1 ? "es" : ""} to your schedule.`,
          });
        } else if (data.task) {
          toast({
            title: "Task created!",
            description: `Added "${data.task.name}" to your schedule.`,
          });
        } else if (data.classes && data.classes.length > 0) {
          const className = data.classes[0].name;
          toast({
            title: "Class added!",
            description: data.classes.length > 1 
              ? `Added "${className}" on ${data.classes.length} days.`
              : `Added "${className}" to your schedule.`,
          });
        }
      }
    },
    onError: (error: Error) => {
      const errorContent = error.message || "I'm sorry, I had trouble processing that. Could you try rephrasing your request?";
      const assistantMessage: ChatMessage = {
        id: Date.now().toString(),
        role: "assistant",
        content: errorContent,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSend = () => {
    if (!inputValue.trim() || chatMutation.isPending) return;
    
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(inputValue.trim());
    setInputValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExampleClick = (prompt: string) => {
    setInputValue(prompt);
    inputRef.current?.focus();
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(":");
    const h = parseInt(hours);
    const ampm = h >= 12 ? "PM" : "AM";
    const h12 = h % 12 || 12;
    return `${h12}:${minutes} ${ampm}`;
  };

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50"
        size="icon"
        data-testid="button-open-chat"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>

      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-[400px] h-[600px] shadow-2xl z-50 flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between gap-2 py-3 px-4 border-b">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              <div>
                <CardTitle className="text-base">AI Assistant</CardTitle>
                <p className="text-xs text-muted-foreground">Add tasks & classes naturally</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsOpen(false)}
              data-testid="button-close-chat"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-lg px-3 py-2 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      
                      {message.task && (
                        <div className="mt-2 p-2 rounded bg-background/50 border">
                          <div className="flex items-center gap-2 text-xs">
                            <CheckCircle className="h-3 w-3 text-green-500" />
                            <span className="font-medium">{message.task.name}</span>
                          </div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {message.task.duration}min
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {message.task.category}
                            </Badge>
                            {message.task.isRecurring && message.task.repeatDays && (
                              <Badge variant="outline" className="text-xs">
                                {message.task.repeatDays.map(d => 
                                  ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][parseInt(d)]
                                ).join(", ")}
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {message.classes && message.classes.length > 0 && (
                        <div className="mt-2 p-2 rounded bg-background/50 border">
                          <div className="flex items-center gap-2 text-xs mb-1">
                            <BookOpen className="h-3 w-3 text-blue-500" />
                            <span className="font-medium">{message.classes[0].name}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {message.classes.map((cls, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][cls.dayOfWeek]} {formatTime(cls.startTime)}-{formatTime(cls.endTime)}
                              </Badge>
                            ))}
                          </div>
                          {message.classes[0].location && (
                            <div className="text-xs text-muted-foreground mt-1">
                              Location: {message.classes[0].location}
                            </div>
                          )}
                        </div>
                      )}
                      
                      {message.scheduling && message.task && (
                        <div className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>Suggested: {formatTime(message.scheduling.suggestedTime)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                
                {chatMutation.isPending && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span className="text-sm text-muted-foreground">Thinking...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              {messages.length === 1 && (
                <div className="mt-4">
                  <p className="text-xs text-muted-foreground mb-2">Try these examples:</p>
                  <div className="flex flex-wrap gap-2">
                    {EXAMPLE_PROMPTS.slice(0, 3).map((prompt, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleExampleClick(prompt)}
                        className="text-xs bg-muted hover:bg-muted/80 px-2 py-1 rounded-full transition-colors text-left"
                        data-testid={`button-example-${idx}`}
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </ScrollArea>
            
            <div className="p-3 border-t">
              <div className="flex gap-2">
                <Input
                  ref={inputRef}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Add a task or class..."
                  disabled={chatMutation.isPending}
                  className="flex-1"
                  data-testid="input-chat-message"
                />
                <Button
                  onClick={handleSend}
                  disabled={!inputValue.trim() || chatMutation.isPending}
                  size="icon"
                  data-testid="button-send-message"
                >
                  {chatMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}
