import { useState, useEffect } from "react";
import { Plus, Loader2, Trash2, Pencil, Clock, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ClassEntry } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClassEntrySchema } from "@shared/schema";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const formSchema = insertClassEntrySchema.omit({ userId: true }).extend({
  name: z.string().min(1, "Class name is required"),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
});

type FormData = z.infer<typeof formSchema>;

export function ClassesPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassEntry | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      dayOfWeek: 1,
      startTime: "09:00",
      endTime: "10:00",
      location: "",
      color: "#3b82f6",
    },
  });

  useEffect(() => {
    if (editingClass) {
      form.reset({
        name: editingClass.name,
        dayOfWeek: editingClass.dayOfWeek,
        startTime: editingClass.startTime,
        endTime: editingClass.endTime,
        location: editingClass.location || "",
        color: editingClass.color || "#3b82f6",
      });
    } else {
      form.reset({
        name: "",
        dayOfWeek: 1,
        startTime: "09:00",
        endTime: "10:00",
        location: "",
        color: "#3b82f6",
      });
    }
  }, [editingClass, form]);

  const { data: classes = [], isLoading } = useQuery<ClassEntry[]>({
    queryKey: ["/api/classes"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const payload = {
        name: data.name,
        dayOfWeek: data.dayOfWeek,
        startTime: data.startTime,
        endTime: data.endTime,
        location: data.location || null,
        color: data.color || "#3b82f6",
      };
      return apiRequest("POST", "/api/classes", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      toast({
        title: "Class created",
        description: "Your class has been added successfully.",
      });
      form.reset();
      setIsOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create class",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: FormData }) => {
      const payload = {
        name: data.name,
        dayOfWeek: data.dayOfWeek,
        startTime: data.startTime,
        endTime: data.endTime,
        location: data.location || null,
        color: data.color || "#3b82f6",
      };
      return apiRequest("PATCH", `/api/classes/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      toast({
        title: "Class updated",
        description: "Your class has been updated successfully.",
      });
      setEditingClass(null);
      setIsOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update class",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/classes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      toast({
        title: "Class deleted",
        description: "Class removed successfully.",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    if (editingClass) {
      updateMutation.mutate({ id: editingClass.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEditClass = (cls: ClassEntry) => {
    setEditingClass(cls);
    setIsOpen(true);
  };

  const handleCloseDialog = (open: boolean) => {
    if (!open) {
      setEditingClass(null);
    }
    setIsOpen(open);
  };

  const groupedClasses = classes.reduce((acc, cls) => {
    const day = cls.dayOfWeek;
    if (!acc[day]) acc[day] = [];
    acc[day].push(cls);
    return acc;
  }, {} as Record<number, ClassEntry[]>);

  Object.values(groupedClasses).forEach(dayClasses => {
    dayClasses.sort((a, b) => a.startTime.localeCompare(b.startTime));
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <CardTitle className="text-xl">My Classes</CardTitle>
            <CardDescription>
              View and manage your weekly class schedule. Classes repeat every week.
            </CardDescription>
          </div>
          <Dialog open={isOpen} onOpenChange={handleCloseDialog}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-class">
                <Plus className="h-4 w-4 mr-2" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingClass ? "Edit Class" : "Add New Class"}</DialogTitle>
                <DialogDescription>
                  {editingClass ? "Update the class details below." : "Enter the details for your new class."}
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Class Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g., AP Calculus"
                            {...field}
                            data-testid="input-class-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dayOfWeek"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Day of Week</FormLabel>
                        <Select 
                          onValueChange={(val) => field.onChange(parseInt(val))} 
                          value={field.value?.toString()}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-class-day">
                              <SelectValue placeholder="Select day" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {DAYS.map((day, index) => (
                              <SelectItem key={day} value={index.toString()}>
                                {day}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Time</FormLabel>
                          <FormControl>
                            <Input
                              type="time"
                              {...field}
                              data-testid="input-class-start-time"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="endTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Time</FormLabel>
                          <FormControl>
                            <Input
                              type="time"
                              {...field}
                              data-testid="input-class-end-time"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location (optional)</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g., Room 101"
                            {...field}
                            value={field.value || ""}
                            data-testid="input-class-location"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-3 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => handleCloseDialog(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createMutation.isPending || updateMutation.isPending}
                      data-testid="button-submit-class"
                    >
                      {(createMutation.isPending || updateMutation.isPending) ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          {editingClass ? "Updating..." : "Creating..."}
                        </>
                      ) : (
                        editingClass ? "Update Class" : "Create Class"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : classes.length === 0 ? (
          <div className="text-center p-8 rounded-lg border border-dashed">
            <Calendar className="h-10 w-10 mx-auto text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">No classes yet. Upload a schedule or add classes manually!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {Object.entries(groupedClasses)
              .sort(([a], [b]) => parseInt(a) - parseInt(b))
              .map(([dayOfWeek, dayClasses]) => (
                <div key={dayOfWeek}>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">
                    {DAYS[parseInt(dayOfWeek)]}
                  </h3>
                  <div className="space-y-2">
                    {dayClasses.map((cls) => (
                      <ClassCard
                        key={cls.id}
                        classEntry={cls}
                        onEdit={() => handleEditClass(cls)}
                        onDelete={() => deleteMutation.mutate(cls.id)}
                      />
                    ))}
                  </div>
                </div>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ClassCard({
  classEntry,
  onEdit,
  onDelete,
}: {
  classEntry: ClassEntry;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className="group flex items-center gap-3 p-3 rounded-lg border transition-colors hover-elevate bg-card"
      data-testid={`card-class-${classEntry.id}`}
    >
      <div 
        className="w-1 h-10 rounded-full shrink-0"
        style={{ backgroundColor: classEntry.color || "#3b82f6" }}
      />
      
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{classEntry.name}</p>
        <div className="flex items-center gap-3 mt-0.5 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            <span>{classEntry.startTime} - {classEntry.endTime}</span>
          </div>
          {classEntry.location && (
            <div className="flex items-center gap-1 truncate">
              <MapPin className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{classEntry.location}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={onEdit}
          data-testid={`button-edit-class-${classEntry.id}`}
        >
          <Pencil className="h-4 w-4 text-muted-foreground" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={onDelete}
          data-testid={`button-delete-class-${classEntry.id}`}
        >
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      </div>
    </div>
  );
}
