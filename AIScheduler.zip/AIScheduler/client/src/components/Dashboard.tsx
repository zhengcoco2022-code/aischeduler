import { Calendar, ListTodo, Clock, CheckCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { Task, ClassEntry, ScheduledBlock } from "@shared/schema";
import { categoryColors, priorityColors } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export function Dashboard() {
  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: classes = [], isLoading: classesLoading } = useQuery<ClassEntry[]>({
    queryKey: ["/api/classes"],
  });

  const { data: scheduledBlocks = [], isLoading: blocksLoading } = useQuery<ScheduledBlock[]>({
    queryKey: ["/api/scheduled-blocks"],
  });

  const { data: scheduleHealth } = useQuery<{ isOverloaded: boolean; message: string; hoursPerDay: Record<string, number> }>({
    queryKey: ["/api/schedule/health"],
  });

  const isLoading = tasksLoading || classesLoading || blocksLoading;

  const pendingTasks = tasks.filter((t) => !t.isCompleted);
  const completedTasks = tasks.filter((t) => t.isCompleted);
  const completionRate = tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0;

  const totalScheduledMinutes = scheduledBlocks
    .filter((b) => !b.isBreak)
    .reduce((acc, block) => {
      const [startH, startM] = block.startTime.split(":").map(Number);
      const [endH, endM] = block.endTime.split(":").map(Number);
      return acc + (endH * 60 + endM) - (startH * 60 + startM);
    }, 0);

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}m`;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const urgentTasks = pendingTasks.filter((t) => t.priority === "urgent" || t.priority === "high");

  const todayDate = new Date();
  const todayDayOfWeek = todayDate.getDay();
  
  const todayClasses = classes.filter((c) => c.dayOfWeek === todayDayOfWeek);
  const todayBlocks = scheduledBlocks.filter((b) => b.dayOfWeek === todayDayOfWeek);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold" data-testid="text-page-title">Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Welcome back! Here's an overview of your schedule and tasks.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
            <ListTodo className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold" data-testid="stat-total-tasks">{tasks.length}</div>
                <p className="text-xs text-muted-foreground">
                  {pendingTasks.length} pending, {completedTasks.length} completed
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Classes</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold" data-testid="stat-total-classes">{classes.length}</div>
                <p className="text-xs text-muted-foreground">
                  {todayClasses.length} classes today
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold" data-testid="stat-scheduled-time">
                  {formatDuration(totalScheduledMinutes)}
                </div>
                <p className="text-xs text-muted-foreground">
                  This week
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold" data-testid="stat-completion-rate">{completionRate}%</div>
                <Progress value={completionRate} className="mt-2" />
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Schedule Health Warning */}
      {scheduleHealth?.isOverloaded && (
        <Card className="border-amber-500/50 bg-amber-500/5">
          <CardContent className="flex items-start gap-4 pt-6">
            <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-amber-700 dark:text-amber-300">
                Schedule Overload Detected
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {scheduleHealth.message}
              </p>
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <Link href="/settings">Adjust Settings</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Today's Schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Today's Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : todayClasses.length === 0 && todayBlocks.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">No events scheduled for today</p>
                <Button variant="outline" size="sm" className="mt-3" asChild>
                  <Link href="/schedule">View Full Schedule</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {todayClasses
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .map((cls) => (
                    <div
                      key={cls.id}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                      data-testid={`today-class-${cls.id}`}
                    >
                      <div
                        className="w-1 h-12 rounded-full"
                        style={{ backgroundColor: cls.color || "#3b82f6" }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{cls.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {cls.startTime} - {cls.endTime}
                          {cls.location && ` • ${cls.location}`}
                        </p>
                      </div>
                      <Badge variant="secondary">Class</Badge>
                    </div>
                  ))}
                {todayBlocks
                  .filter((b) => !b.isBreak)
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .slice(0, 5)
                  .map((block) => {
                    const task = tasks.find((t) => t.id === block.taskId);
                    const blockSource = (block as any).source;
                    const isStudyPlan = blockSource === "study_plan";
                    const blockColor = isStudyPlan 
                      ? "#10b981" // Emerald green for study plan
                      : (task ? categoryColors[task.category] : "#8b5cf6");
                    return (
                      <div
                        key={block.id}
                        className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                        data-testid={`today-block-${block.id}`}
                      >
                        <div
                          className="w-1 h-12 rounded-full"
                          style={{ backgroundColor: blockColor }}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{task?.name || "Task"}</p>
                          <p className="text-sm text-muted-foreground">
                            {block.startTime} - {block.endTime}
                          </p>
                        </div>
                        <Badge 
                          variant="outline"
                          className={isStudyPlan ? "border-emerald-500 text-emerald-600 dark:text-emerald-400" : ""}
                        >
                          {isStudyPlan ? "Study Plan" : "Task"}
                        </Badge>
                      </div>
                    );
                  })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Urgent Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Priority Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : urgentTasks.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                <p className="text-muted-foreground">No urgent tasks! Great job!</p>
                <Button variant="outline" size="sm" className="mt-3" asChild>
                  <Link href="/tasks">View All Tasks</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {urgentTasks.slice(0, 5).map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                    data-testid={`urgent-task-${task.id}`}
                  >
                    <div
                      className="w-1 h-12 rounded-full"
                      style={{ backgroundColor: priorityColors[task.priority] }}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{task.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge
                          variant="outline"
                          className="text-xs"
                          style={{ borderColor: priorityColors[task.priority], color: priorityColors[task.priority] }}
                        >
                          {task.priority}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatDuration(task.duration)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                {urgentTasks.length > 5 && (
                  <Button variant="ghost" className="w-full" asChild>
                    <Link href="/tasks">View all {urgentTasks.length} priority tasks</Link>
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button asChild>
              <Link href="/upload" data-testid="button-quick-upload">
                Upload Class Schedule
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/tasks" data-testid="button-quick-tasks">
                Add New Task
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/schedule" data-testid="button-quick-schedule">
                View Weekly Schedule
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
