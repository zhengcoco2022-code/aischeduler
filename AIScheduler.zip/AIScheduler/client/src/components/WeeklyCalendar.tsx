import { useState, useCallback, useMemo } from "react";
import { ChevronLeft, ChevronRight, RefreshCw, AlertTriangle, Coffee, Loader2, MapPin, Clock, Calendar, Flag, Tag, FileText, CalendarDays, LayoutGrid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ClassEntry, Task, ScheduledBlock } from "@shared/schema";
import { categoryColors } from "@shared/schema";
import { format } from "date-fns";

const HOURS = Array.from({ length: 17 }, (_, i) => i + 6);
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const FULL_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

interface CalendarEvent {
  id: string;
  title: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  color: string;
  type: "class" | "task" | "break";
  taskId?: string;
  source?: string;
  location?: string;
  duration?: number;
  deadline?: Date | string | null;
  priority?: string;
  category?: string;
  notes?: string;
  scheduledDate?: string;
}

const STUDY_PLAN_COLOR = "#10b981";

const priorityLabels: Record<string, { label: string; color: string }> = {
  low: { label: "Low", color: "text-green-600" },
  medium: { label: "Medium", color: "text-yellow-600" },
  high: { label: "High", color: "text-orange-600" },
  urgent: { label: "Urgent", color: "text-red-600" },
};

const categoryLabels: Record<string, string> = {
  school: "School",
  workout: "Workout",
  personal: "Personal",
  health: "Health",
  other: "Other",
};

type ViewMode = "week" | "day";

export function WeeklyCalendar() {
  const [viewMode, setViewMode] = useState<ViewMode>("week");
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    const diff = today.getDate() - dayOfWeek;
    return new Date(today.setDate(diff));
  });
  const [selectedDay, setSelectedDay] = useState(() => new Date());
  const [draggedEvent, setDraggedEvent] = useState<CalendarEvent | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: classes = [] } = useQuery<ClassEntry[]>({
    queryKey: ["/api/classes"],
    staleTime: 0, // Always refetch when component mounts to ensure fresh data
    refetchOnMount: 'always',
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: scheduledBlocks = [] } = useQuery<ScheduledBlock[]>({
    queryKey: ["/api/scheduled-blocks"],
  });

  const { data: scheduleHealth } = useQuery<{ isOverloaded: boolean; message: string; hoursPerDay: Record<string, number> }>({
    queryKey: ["/api/schedule/health"],
  });

  const regenerateMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/schedule/generate");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-blocks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule/health"] });
      toast({
        title: "Schedule regenerated",
        description: "Your schedule has been optimized with AI.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to regenerate",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const moveBlockMutation = useMutation({
    mutationFn: async ({ blockId, dayOfWeek, startTime }: { blockId: string; dayOfWeek: number; startTime: string }) => {
      return apiRequest("PATCH", `/api/scheduled-blocks/${blockId}`, { dayOfWeek, startTime });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-blocks"] });
      toast({
        title: "Block moved",
        description: "Schedule updated successfully.",
      });
    },
  });

  const getWeekDates = useCallback(() => {
    const dates: string[] = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(currentWeekStart);
      date.setDate(currentWeekStart.getDate() + i);
      dates.push(date.toISOString().split('T')[0]);
    }
    return dates;
  }, [currentWeekStart]);

  const events = useMemo<CalendarEvent[]>(() => {
    const weekDates = getWeekDates();

    const classEvents: CalendarEvent[] = classes.map((cls) => ({
      id: `class-${cls.id}`,
      title: cls.name,
      dayOfWeek: cls.dayOfWeek,
      startTime: cls.startTime,
      endTime: cls.endTime,
      color: cls.color || "#3b82f6",
      type: "class" as const,
      location: cls.location || undefined,
    }));

    const taskEvents: CalendarEvent[] = scheduledBlocks
      .filter((block) => {
        if (block.isBreak) return false;
        const blockDate = (block as any).scheduledDate;
        if (blockDate) {
          return weekDates.includes(blockDate);
        }
        return true;
      })
      .map((block) => {
        const task = tasks.find((t) => t.id === block.taskId);
        const blockDate = (block as any).scheduledDate;
        const blockSource = (block as any).source;
        let dayOfWeek = block.dayOfWeek;
        if (blockDate) {
          const dateObj = new Date(blockDate + 'T00:00:00');
          dayOfWeek = dateObj.getDay();
        }
        const color = blockSource === "study_plan" 
          ? STUDY_PLAN_COLOR 
          : (task ? categoryColors[task.category] : "#8b5cf6");
        return {
          id: `block-${block.id}`,
          title: task?.name || "Task",
          dayOfWeek,
          startTime: block.startTime,
          endTime: block.endTime,
          color,
          type: "task" as const,
          taskId: block.taskId || undefined,
          source: blockSource,
          duration: task?.duration,
          deadline: task?.deadline,
          priority: task?.priority,
          category: task?.category,
          notes: task?.notes || undefined,
          scheduledDate: blockDate,
        };
      });

    const breakEvents: CalendarEvent[] = scheduledBlocks
      .filter((block) => {
        if (!block.isBreak) return false;
        const blockDate = (block as any).scheduledDate;
        if (blockDate) {
          return weekDates.includes(blockDate);
        }
        return true;
      })
      .map((block) => {
        const blockDate = (block as any).scheduledDate;
        let dayOfWeek = block.dayOfWeek;
        if (blockDate) {
          const dateObj = new Date(blockDate + 'T00:00:00');
          dayOfWeek = dateObj.getDay();
        }
        return {
          id: `break-${block.id}`,
          title: "Break",
          dayOfWeek,
          startTime: block.startTime,
          endTime: block.endTime,
          color: "#94a3b8",
          type: "break" as const,
        };
      });

    return [...classEvents, ...taskEvents, ...breakEvents];
  }, [classes, tasks, scheduledBlocks, getWeekDates]);

  const timeToMinutes = (time: string) => {
    const [hours, minutes] = time.split(":").map(Number);
    return hours * 60 + minutes;
  };

  const getOverlapInfo = useMemo(() => {
    const overlapMap = new Map<string, { index: number; total: number }>();
    
    const eventsByDay = new Map<number, CalendarEvent[]>();
    events.forEach(event => {
      const dayEvents = eventsByDay.get(event.dayOfWeek) || [];
      dayEvents.push(event);
      eventsByDay.set(event.dayOfWeek, dayEvents);
    });

    eventsByDay.forEach((dayEvents) => {
      const sorted = [...dayEvents].sort((a, b) => 
        timeToMinutes(a.startTime) - timeToMinutes(b.startTime)
      );

      const groups: CalendarEvent[][] = [];
      
      sorted.forEach(event => {
        const eventStart = timeToMinutes(event.startTime);
        const eventEnd = timeToMinutes(event.endTime);
        
        let addedToGroup = false;
        for (const group of groups) {
          const groupEnd = Math.max(...group.map(e => timeToMinutes(e.endTime)));
          const groupStart = Math.min(...group.map(e => timeToMinutes(e.startTime)));
          
          if (eventStart < groupEnd && eventEnd > groupStart) {
            group.push(event);
            addedToGroup = true;
            break;
          }
        }
        
        if (!addedToGroup) {
          groups.push([event]);
        }
      });

      groups.forEach(group => {
        const columns: CalendarEvent[][] = [];
        
        group.forEach(event => {
          const eventStart = timeToMinutes(event.startTime);
          
          let placed = false;
          for (let col = 0; col < columns.length; col++) {
            const lastInColumn = columns[col][columns[col].length - 1];
            const lastEnd = timeToMinutes(lastInColumn.endTime);
            
            if (eventStart >= lastEnd) {
              columns[col].push(event);
              placed = true;
              break;
            }
          }
          
          if (!placed) {
            columns.push([event]);
          }
        });

        const totalColumns = columns.length;
        columns.forEach((col, colIndex) => {
          col.forEach(event => {
            overlapMap.set(event.id, { index: colIndex, total: totalColumns });
          });
        });
      });
    });

    return overlapMap;
  }, [events]);

  const getEventStyle = (event: CalendarEvent) => {
    const startMinutes = timeToMinutes(event.startTime) - 6 * 60;
    const endMinutes = timeToMinutes(event.endTime) - 6 * 60;
    const duration = endMinutes - startMinutes;
    
    const hourHeight = 72; // Increased from 56 for better readability
    const top = (startMinutes / 60) * hourHeight;
    const height = Math.max((duration / 60) * hourHeight, 40); // Min height 40px

    return {
      top: `${top}px`,
      height: `${height}px`,
    };
  };

  const handleDragStart = (event: CalendarEvent) => {
    if (event.type !== "task") return;
    setDraggedEvent(event);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (dayOfWeek: number, hour: number) => {
    if (!draggedEvent || draggedEvent.type !== "task") return;

    const blockId = draggedEvent.id.replace("block-", "");
    const startTime = `${hour.toString().padStart(2, "0")}:00`;
    
    moveBlockMutation.mutate({ blockId, dayOfWeek, startTime });
    setDraggedEvent(null);
  };

  const navigateWeek = (direction: number) => {
    setCurrentWeekStart((prev) => {
      const newDate = new Date(prev);
      newDate.setDate(newDate.getDate() + direction * 7);
      return newDate;
    });
  };

  const navigateDay = (direction: number) => {
    setSelectedDay((prev) => {
      const newDate = new Date(prev);
      newDate.setDate(newDate.getDate() + direction);
      return newDate;
    });
  };

  const goToToday = () => {
    const today = new Date();
    if (viewMode === "week") {
      const dayOfWeek = today.getDay();
      const diff = today.getDate() - dayOfWeek;
      setCurrentWeekStart(new Date(today.setDate(diff)));
    } else {
      setSelectedDay(new Date());
    }
  };

  const formatWeekRange = () => {
    const end = new Date(currentWeekStart);
    end.setDate(end.getDate() + 6);
    const startMonth = currentWeekStart.toLocaleDateString("en-US", { month: "short" });
    const endMonth = end.toLocaleDateString("en-US", { month: "short" });
    const startDay = currentWeekStart.getDate();
    const endDay = end.getDate();
    
    if (startMonth === endMonth) {
      return `${startMonth} ${startDay} - ${endDay}, ${currentWeekStart.getFullYear()}`;
    }
    return `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${currentWeekStart.getFullYear()}`;
  };

  const formatDayTitle = () => {
    return selectedDay.toLocaleDateString("en-US", { 
      weekday: "long", 
      month: "long", 
      day: "numeric",
      year: "numeric"
    });
  };

  const getDayEvents = useMemo(() => {
    const dayOfWeek = selectedDay.getDay();
    const dateStr = selectedDay.toISOString().split('T')[0];
    
    return events.filter(event => {
      if (event.scheduledDate) {
        return event.scheduledDate === dateStr;
      }
      return event.dayOfWeek === dayOfWeek;
    }).sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
  }, [events, selectedDay]);

  const getEventTypeColor = (event: CalendarEvent) => {
    if (event.type === "break") return "bg-slate-100 dark:bg-slate-800/50 border-slate-300 dark:border-slate-600";
    if (event.type === "class") return "";
    if (event.source === "study_plan") return "";
    return "";
  };

  return (
    <div className="space-y-4">
      {scheduleHealth?.isOverloaded && (
        <Alert variant="destructive" className="border-amber-500/50 bg-amber-50 dark:bg-amber-950/20">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-700 dark:text-amber-300">
            {scheduleHealth.message}
          </AlertDescription>
        </Alert>
      )}

      <Card className="overflow-hidden">
        <CardHeader className="pb-4 border-b bg-muted/30">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="flex items-center bg-background rounded-lg border p-0.5">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => viewMode === "week" ? navigateWeek(-1) : navigateDay(-1)}
                  data-testid="button-prev"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 px-2 text-xs"
                  onClick={goToToday}
                  data-testid="button-today"
                >
                  Today
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => viewMode === "week" ? navigateWeek(1) : navigateDay(1)}
                  data-testid="button-next"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
              <CardTitle className="text-lg font-semibold" data-testid="text-date-range">
                {viewMode === "week" ? formatWeekRange() : formatDayTitle()}
              </CardTitle>
            </div>
            
            <div className="flex items-center gap-3">
              <ToggleGroup 
                type="single" 
                value={viewMode} 
                onValueChange={(value) => value && setViewMode(value as ViewMode)}
                className="bg-background rounded-lg border p-0.5"
              >
                <ToggleGroupItem 
                  value="day" 
                  aria-label="Day view"
                  className="h-8 px-3 text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground"
                  data-testid="toggle-day-view"
                >
                  <List className="h-4 w-4 mr-1.5" />
                  Day
                </ToggleGroupItem>
                <ToggleGroupItem 
                  value="week" 
                  aria-label="Week view"
                  className="h-8 px-3 text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground"
                  data-testid="toggle-week-view"
                >
                  <LayoutGrid className="h-4 w-4 mr-1.5" />
                  Week
                </ToggleGroupItem>
              </ToggleGroup>

            <Button
              size="sm"
              onClick={() => regenerateMutation.mutate()}
              disabled={regenerateMutation.isPending}
              data-testid="button-regenerate-schedule"
            >
              {regenerateMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Regenerate
            </Button>
            </div>
          </div>

          <div className="flex items-center gap-6 mt-3">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
              <span className="text-xs text-muted-foreground">Classes</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-purple-500" />
              <span className="text-xs text-muted-foreground">Tasks</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-xs text-muted-foreground">Study Plan</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Coffee className="h-3 w-3 text-slate-400" />
              <span className="text-xs text-muted-foreground">Breaks</span>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0 overflow-x-auto">
          {viewMode === "week" ? (
            <div className="min-w-[800px]">
              <div className="grid grid-cols-8 border-b bg-muted/20">
                <div className="p-3 text-xs font-medium text-muted-foreground text-center w-16">
                  
                </div>
                {DAYS.map((day, index) => {
                  const date = new Date(currentWeekStart);
                  date.setDate(date.getDate() + index);
                  const isToday = new Date().toDateString() === date.toDateString();
                  
                  return (
                    <div
                      key={day}
                      className={`p-3 text-center border-l flex flex-col items-center ${isToday ? "bg-primary/5" : ""}`}
                      data-testid={`header-day-${index}`}
                    >
                      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{day}</span>
                      <span className={`text-lg font-semibold mt-0.5 ${
                        isToday 
                          ? "bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center" 
                          : ""
                      }`}>
                        {date.getDate()}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="relative">
                {HOURS.map((hour) => (
                  <div key={hour} className="grid grid-cols-8 border-b border-dashed border-border/50" style={{ height: "72px" }}>
                    <div className="p-1 text-xs text-muted-foreground text-right pr-2 pt-0 -mt-2 w-16">
                      {hour === 12 ? "12 PM" : hour > 12 ? `${hour - 12} PM` : `${hour} AM`}
                    </div>
                    {DAYS.map((_, dayIndex) => {
                      const date = new Date(currentWeekStart);
                      date.setDate(date.getDate() + dayIndex);
                      const isToday = new Date().toDateString() === date.toDateString();
                      
                      return (
                        <div
                          key={dayIndex}
                          className={`border-l border-border/30 relative ${isToday ? "bg-primary/[0.02]" : ""}`}
                          onDragOver={handleDragOver}
                          onDrop={() => handleDrop(dayIndex, hour)}
                          data-testid={`cell-${dayIndex}-${hour}`}
                        />
                      );
                    })}
                  </div>
                ))}

                {events.map((event) => {
                  const style = getEventStyle(event);
                  const overlapInfo = getOverlapInfo.get(event.id) || { index: 0, total: 1 };
                  const columnWidth = 100 / 8;
                  const eventWidthPercent = (columnWidth / overlapInfo.total) * 0.95;
                  const leftOffset = event.dayOfWeek * columnWidth + columnWidth + (overlapInfo.index * (columnWidth / overlapInfo.total));
                  
                  const isBreak = event.type === "break";
                  
                  return (
                    <div
                      key={event.id}
                      className={`absolute rounded-lg overflow-hidden cursor-pointer transition-all duration-150 ${
                        isBreak 
                          ? "border border-dashed border-slate-300 dark:border-slate-600 bg-slate-100/80 dark:bg-slate-800/50" 
                          : "shadow-sm hover:shadow-lg hover:scale-[1.01] hover:z-50 border"
                      }`}
                      style={{
                        ...style,
                        left: `calc(${leftOffset}% + 2px)`,
                        width: `calc(${eventWidthPercent}% - 4px)`,
                        zIndex: event.type === "task" ? 10 : 5,
                        backgroundColor: isBreak ? undefined : `${event.color}20`,
                        borderColor: isBreak ? undefined : `${event.color}40`,
                        borderLeftWidth: isBreak ? undefined : '4px',
                        borderLeftColor: isBreak ? undefined : event.color,
                      }}
                      draggable={event.type === "task"}
                      onDragStart={() => handleDragStart(event)}
                      onClick={() => !isBreak && setSelectedEvent(event)}
                      data-testid={`event-${event.id}`}
                      title={`${event.title}\n${event.startTime} - ${event.endTime}${event.location ? `\n${event.location}` : ''}`}
                    >
                      {isBreak ? (
                        <div className="flex items-center justify-center h-full gap-1 text-xs text-slate-400">
                          <Coffee className="h-3 w-3" />
                          <span>Break</span>
                        </div>
                      ) : (
                        <div className="h-full p-2 flex flex-col overflow-hidden">
                          <div 
                            className="text-xs font-semibold leading-snug break-words" 
                            style={{ color: event.color }}
                          >
                            {event.title}
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-auto pt-1 flex items-center gap-1">
                            <span>{event.startTime} - {event.endTime}</span>
                            {event.location && (
                              <span className="truncate opacity-75">• {event.location}</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="p-4">
              <div className="grid grid-cols-[80px_1fr] gap-4">
                <div className="text-sm text-muted-foreground font-medium pt-2">Time</div>
                <div className="text-sm font-semibold">
                  {selectedDay.toLocaleDateString("en-US", { weekday: "long" })} Schedule
                </div>
              </div>
              
              {getDayEvents.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <CalendarDays className="h-12 w-12 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">No events scheduled for this day</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Add tasks or classes to see them here
                  </p>
                </div>
              ) : (
                <div className="mt-4 space-y-3">
                  {getDayEvents.map((event) => {
                    const isBreak = event.type === "break";
                    
                    return (
                      <div
                        key={event.id}
                        className={`grid grid-cols-[80px_1fr] gap-4 ${!isBreak ? 'cursor-pointer' : ''}`}
                        onClick={() => !isBreak && setSelectedEvent(event)}
                        data-testid={`day-event-${event.id}`}
                      >
                        <div className="text-sm text-muted-foreground py-3">
                          {event.startTime}
                        </div>
                        <div
                          className={`rounded-lg p-4 transition-all ${
                            isBreak
                              ? "border border-dashed border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800/30"
                              : "shadow-sm hover:shadow-md border"
                          }`}
                          style={{
                            backgroundColor: isBreak ? undefined : `${event.color}15`,
                            borderColor: isBreak ? undefined : `${event.color}30`,
                            borderLeftWidth: isBreak ? undefined : '4px',
                            borderLeftColor: isBreak ? undefined : event.color,
                          }}
                        >
                          {isBreak ? (
                            <div className="flex items-center gap-2 text-slate-400">
                              <Coffee className="h-4 w-4" />
                              <span>Break</span>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <div className="flex items-start justify-between gap-2">
                                <h3 
                                  className="font-semibold text-base"
                                  style={{ color: event.color }}
                                >
                                  {event.title}
                                </h3>
                                <Badge 
                                  variant="secondary" 
                                  className="text-xs shrink-0"
                                  style={{ 
                                    backgroundColor: `${event.color}20`,
                                    color: event.color 
                                  }}
                                >
                                  {event.type === "class" ? "Class" : event.source === "study_plan" ? "Study" : "Task"}
                                </Badge>
                              </div>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="h-3.5 w-3.5" />
                                  <span>{event.startTime} - {event.endTime}</span>
                                </div>
                                {event.location && (
                                  <div className="flex items-center gap-1.5">
                                    <MapPin className="h-3.5 w-3.5" />
                                    <span className="truncate max-w-[200px]">{event.location}</span>
                                  </div>
                                )}
                              </div>
                              
                              {event.priority && (
                                <div className="flex items-center gap-1.5 text-sm">
                                  <Flag className={`h-3.5 w-3.5 ${priorityLabels[event.priority]?.color || ""}`} />
                                  <span className={priorityLabels[event.priority]?.color || ""}>
                                    {priorityLabels[event.priority]?.label || event.priority} priority
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selectedEvent} onOpenChange={(open) => !open && setSelectedEvent(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <div 
                className="w-1 h-12 rounded-full" 
                style={{ backgroundColor: selectedEvent?.color }}
              />
              <div>
                <DialogTitle className="text-lg">
                  {selectedEvent?.title}
                </DialogTitle>
                <div className="flex items-center gap-2 mt-1.5">
                  {selectedEvent?.type === "class" ? (
                    <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                      Class
                    </Badge>
                  ) : selectedEvent?.source === "study_plan" ? (
                    <Badge variant="secondary" className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
                      Study Plan
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300">
                      Task
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-3 mt-4">
            <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Time</p>
                <p className="text-sm font-medium">
                  {selectedEvent?.startTime} - {selectedEvent?.endTime}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Date</p>
                <p className="text-sm font-medium">
                  {selectedEvent?.scheduledDate 
                    ? format(new Date(selectedEvent.scheduledDate + 'T00:00:00'), "EEEE, MMMM d, yyyy")
                    : FULL_DAYS[selectedEvent?.dayOfWeek || 0]
                  }
                </p>
              </div>
            </div>

            {selectedEvent?.location && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Location</p>
                  <p className="text-sm font-medium">{selectedEvent.location}</p>
                </div>
              </div>
            )}

            {selectedEvent?.duration && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Duration</p>
                  <p className="text-sm font-medium">
                    {selectedEvent.duration >= 60 
                      ? `${Math.floor(selectedEvent.duration / 60)}h ${selectedEvent.duration % 60 > 0 ? `${selectedEvent.duration % 60}m` : ''}`
                      : `${selectedEvent.duration} minutes`
                    }
                  </p>
                </div>
              </div>
            )}

            {selectedEvent?.priority && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <Flag className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Priority</p>
                  <p className={`text-sm font-medium ${priorityLabels[selectedEvent.priority]?.color || ''}`}>
                    {priorityLabels[selectedEvent.priority]?.label || selectedEvent.priority}
                  </p>
                </div>
              </div>
            )}

            {selectedEvent?.category && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <Tag className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Category</p>
                  <p className="text-sm font-medium">
                    {categoryLabels[selectedEvent.category] || selectedEvent.category}
                  </p>
                </div>
              </div>
            )}

            {selectedEvent?.deadline && (
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Deadline</p>
                  <p className="text-sm font-medium">
                    {format(new Date(selectedEvent.deadline), "EEEE, MMMM d 'at' h:mm a")}
                  </p>
                </div>
              </div>
            )}

            {selectedEvent?.notes && (
              <div className="flex items-start gap-3 p-2.5 rounded-lg bg-muted/50">
                <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Notes</p>
                  <p className="text-sm whitespace-pre-wrap">
                    {selectedEvent.notes}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end mt-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setSelectedEvent(null)}
              data-testid="button-close-event-dialog"
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
