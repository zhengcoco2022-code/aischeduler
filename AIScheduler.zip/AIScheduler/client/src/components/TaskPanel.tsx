import { useState, useEffect } from "react";
import { Plus, Loader2, Trash2, CheckCircle, Circle, GripVertical, Pencil, Repeat, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Task } from "@shared/schema";
import { categoryColors, priorityColors } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTaskSchema } from "@shared/schema";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const formSchema = insertTaskSchema.omit({ userId: true }).extend({
  name: z.string().min(1, "Task name is required"),
  duration: z.coerce.number().min(5, "Duration must be at least 5 minutes"),
  deadline: z.string().optional(),
  isRecurring: z.boolean().default(false),
  repeatDays: z.array(z.string()).default([]),
});

type FormData = z.infer<typeof formSchema>;

const DAY_OPTIONS = [
  { value: "0", label: "Sun" },
  { value: "1", label: "Mon" },
  { value: "2", label: "Tue" },
  { value: "3", label: "Wed" },
  { value: "4", label: "Thu" },
  { value: "5", label: "Fri" },
  { value: "6", label: "Sat" },
];

export function TaskPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      duration: 30,
      priority: "medium",
      category: "personal",
      notes: "",
      isRecurring: false,
      repeatDays: [],
    },
  });

  const isRecurring = form.watch("isRecurring");

  useEffect(() => {
    if (editingTask) {
      form.reset({
        name: editingTask.name,
        duration: editingTask.duration,
        priority: editingTask.priority,
        category: editingTask.category,
        notes: editingTask.notes || "",
        deadline: editingTask.deadline 
          ? new Date(editingTask.deadline).toISOString().slice(0, 16) 
          : undefined,
        isRecurring: editingTask.isRecurring || false,
        repeatDays: editingTask.repeatDays || [],
      });
    } else {
      form.reset({
        name: "",
        duration: 30,
        priority: "medium",
        category: "personal",
        notes: "",
        isRecurring: false,
        repeatDays: [],
      });
    }
  }, [editingTask, form]);

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const payload = {
        name: data.name,
        duration: data.duration,
        priority: data.priority,
        category: data.category,
        notes: data.notes || null,
        deadline: data.deadline ? new Date(data.deadline) : null,
        isRecurring: data.isRecurring,
        repeatDays: data.isRecurring ? data.repeatDays : null,
      };
      return apiRequest("POST", "/api/tasks", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task created",
        description: "Your task has been added successfully.",
      });
      form.reset();
      setIsOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: FormData }) => {
      const payload = {
        name: data.name,
        duration: data.duration,
        priority: data.priority,
        category: data.category,
        notes: data.notes || null,
        deadline: data.deadline ? new Date(data.deadline) : null,
        isRecurring: data.isRecurring,
        repeatDays: data.isRecurring ? data.repeatDays : null,
      };
      return apiRequest("PATCH", `/api/tasks/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task updated",
        description: "Your task has been updated successfully.",
      });
      setEditingTask(null);
      setIsOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted",
        description: "Task removed successfully.",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, isCompleted }: { id: string; isCompleted: boolean }) => {
      return apiRequest("PATCH", `/api/tasks/${id}`, { isCompleted });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  const onSubmit = (data: FormData) => {
    if (editingTask) {
      updateMutation.mutate({ id: editingTask.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsOpen(true);
  };

  const handleCloseDialog = (open: boolean) => {
    if (!open) {
      setEditingTask(null);
    }
    setIsOpen(open);
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const pendingTasks = tasks.filter((t) => !t.isCompleted);
  const completedTasks = tasks.filter((t) => t.isCompleted);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <CardTitle className="text-xl">Tasks</CardTitle>
              <CardDescription>
                Add tasks that need to be scheduled. The AI will find the best time slots for them.
              </CardDescription>
            </div>
            <Dialog open={isOpen} onOpenChange={handleCloseDialog}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-task">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Task
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>{editingTask ? "Edit Task" : "Create New Task"}</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Task Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g., Study for Math Exam"
                              {...field}
                              data-testid="input-task-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration (minutes)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min={5}
                                step={5}
                                {...field}
                                data-testid="input-task-duration"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="deadline"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Deadline (optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="datetime-local"
                                {...field}
                                data-testid="input-task-deadline"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="priority"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Priority</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-task-priority">
                                  <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="urgent">Urgent</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-task-category">
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="school">School</SelectItem>
                                <SelectItem value="workout">Workout</SelectItem>
                                <SelectItem value="personal">Personal</SelectItem>
                                <SelectItem value="health">Health</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes (optional)</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Any additional details..."
                              className="resize-none"
                              {...field}
                              value={field.value || ""}
                              data-testid="input-task-notes"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-3 pt-2 border-t">
                      <FormLabel className="text-sm font-medium">Task Schedule</FormLabel>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant={!isRecurring ? "default" : "outline"}
                          size="sm"
                          onClick={() => {
                            form.setValue("isRecurring", false);
                            form.setValue("repeatDays", []);
                          }}
                          className="flex items-center gap-2"
                          data-testid="button-one-off"
                        >
                          <Calendar className="h-4 w-4" />
                          One-off
                        </Button>
                        <Button
                          type="button"
                          variant={isRecurring ? "default" : "outline"}
                          size="sm"
                          onClick={() => form.setValue("isRecurring", true)}
                          className="flex items-center gap-2"
                          data-testid="button-repeating"
                        >
                          <Repeat className="h-4 w-4" />
                          Repeating
                        </Button>
                      </div>

                      {isRecurring && (
                        <FormField
                          control={form.control}
                          name="repeatDays"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm text-muted-foreground">Repeat on these days:</FormLabel>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {DAY_OPTIONS.map((day) => {
                                  const isSelected = field.value?.includes(day.value);
                                  return (
                                    <Button
                                      key={day.value}
                                      type="button"
                                      variant={isSelected ? "default" : "outline"}
                                      size="sm"
                                      className="w-12 h-9"
                                      onClick={() => {
                                        const newValue = isSelected
                                          ? field.value.filter((d) => d !== day.value)
                                          : [...(field.value || []), day.value];
                                        field.onChange(newValue);
                                      }}
                                      data-testid={`button-day-${day.value}`}
                                    >
                                      {day.label}
                                    </Button>
                                  );
                                })}
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>

                    <div className="flex justify-end gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => handleCloseDialog(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createMutation.isPending || updateMutation.isPending}
                        data-testid="button-submit-task"
                      >
                        {(createMutation.isPending || updateMutation.isPending) ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                            {editingTask ? "Updating..." : "Creating..."}
                          </>
                        ) : (
                          editingTask ? "Update Task" : "Create Task"
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : tasks.length === 0 ? (
            <div className="text-center p-8 rounded-lg border border-dashed">
              <p className="text-muted-foreground">No tasks yet. Add your first task to get started!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {pendingTasks.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Pending ({pendingTasks.length})
                  </h3>
                  {pendingTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggle={() => toggleMutation.mutate({ id: task.id, isCompleted: true })}
                      onEdit={() => handleEditTask(task)}
                      onDelete={() => deleteMutation.mutate(task.id)}
                      formatDuration={formatDuration}
                    />
                  ))}
                </div>
              )}

              {completedTasks.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground">
                    Completed ({completedTasks.length})
                  </h3>
                  {completedTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onToggle={() => toggleMutation.mutate({ id: task.id, isCompleted: false })}
                      onEdit={() => handleEditTask(task)}
                      onDelete={() => deleteMutation.mutate(task.id)}
                      formatDuration={formatDuration}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function TaskCard({
  task,
  onToggle,
  onEdit,
  onDelete,
  formatDuration,
}: {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  formatDuration: (minutes: number) => string;
}) {
  return (
    <div
      className={`group flex items-center gap-3 p-4 rounded-lg border transition-colors hover-elevate ${
        task.isCompleted ? "bg-muted/30" : "bg-card"
      }`}
      data-testid={`card-task-${task.id}`}
    >
      <button
        onClick={onToggle}
        className="flex-shrink-0"
        data-testid={`button-toggle-task-${task.id}`}
      >
        {task.isCompleted ? (
          <CheckCircle className="h-5 w-5 text-green-500" />
        ) : (
          <Circle className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors" />
        )}
      </button>

      <div className="flex-1 min-w-0">
        <p
          className={`font-medium ${
            task.isCompleted ? "line-through text-muted-foreground" : ""
          }`}
        >
          {task.name}
        </p>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <Badge
            variant="secondary"
            className="text-xs"
            style={{ backgroundColor: `${categoryColors[task.category]}20`, color: categoryColors[task.category] }}
          >
            {task.category}
          </Badge>
          <Badge
            variant="outline"
            className="text-xs"
            style={{ borderColor: priorityColors[task.priority], color: priorityColors[task.priority] }}
          >
            {task.priority}
          </Badge>
          <span className="text-xs text-muted-foreground">
            {formatDuration(task.duration)}
          </span>
          {task.isRecurring && task.repeatDays && task.repeatDays.length > 0 && (
            <Badge variant="outline" className="text-xs flex items-center gap-1">
              <Repeat className="h-3 w-3" />
              {task.repeatDays.map(d => ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][parseInt(d)]).join(", ")}
            </Badge>
          )}
          {task.deadline && (
            <span className="text-xs text-muted-foreground">
              Due: {new Date(task.deadline).toLocaleDateString()}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={onEdit}
          data-testid={`button-edit-task-${task.id}`}
        >
          <Pencil className="h-4 w-4 text-muted-foreground" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={onDelete}
          data-testid={`button-delete-task-${task.id}`}
        >
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      </div>
    </div>
  );
}
