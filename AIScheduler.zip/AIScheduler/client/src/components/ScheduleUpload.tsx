import { useState, useCallback } from "react";
import { Upload, Image, Loader2, CheckCircle, AlertCircle, X, Calendar, Link2, Unlink } from "lucide-react";
import { SiGooglecalendar } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ClassesPanel } from "./ClassesPanel";

interface ExtractedClass {
  name: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  location?: string;
}

interface GoogleCalendarStatus {
  connected: boolean;
  email?: string;
  error?: string;
  needsCredentials?: boolean;
}

export function ScheduleUpload() {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [extractedClasses, setExtractedClasses] = useState<ExtractedClass[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query Google Calendar connection status
  const { data: googleStatus, isLoading: isLoadingStatus } = useQuery<GoogleCalendarStatus>({
    queryKey: ['/api/google-calendar/status'],
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);
      
      const response = await fetch("/api/schedule/extract", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to extract schedule");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setExtractedClasses(data.classes || []);
      toast({
        title: "Schedule extracted!",
        description: `Found ${data.classes?.length || 0} classes in your schedule.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Extraction failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (classes: ExtractedClass[]) => {
      return apiRequest("POST", "/api/classes/bulk", { classes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      toast({
        title: "Classes saved!",
        description: "Your class schedule has been saved successfully.",
      });
      setExtractedClasses([]);
      setPreview(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const googleImportMutation = useMutation({
    mutationFn: async (): Promise<{ imported: number; total: number }> => {
      const response = await apiRequest("POST", "/api/google-calendar/import", { 
        calendarId: 'primary',
        daysAhead: 30 
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/google-calendar/status"] });
      toast({
        title: "Google Calendar imported!",
        description: `Successfully imported ${data.imported} events from your calendar.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Connect to Google Calendar
  const connectMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/auth/google');
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to get authorization URL');
      }
      return response.json();
    },
    onSuccess: (data: { authUrl: string }) => {
      window.location.href = data.authUrl;
    },
    onError: (error: Error) => {
      toast({
        title: "Connection failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Disconnect from Google Calendar
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/google-calendar/disconnect", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/google-calendar/status'] });
      toast({
        title: "Disconnected",
        description: "Google Calendar has been disconnected.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Disconnect failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find((file) => file.type.startsWith("image/"));
    
    if (imageFile) {
      processFile(imageFile);
    } else {
      toast({
        title: "Invalid file",
        description: "Please upload an image file.",
        variant: "destructive",
      });
    }
  }, []);

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
    uploadMutation.mutate(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const clearUpload = () => {
    setPreview(null);
    setExtractedClasses([]);
  };

  const getDayName = (day: number) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return days[day] || "Unknown";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Upload Class Schedule</CardTitle>
          <CardDescription>
            Upload a screenshot or photo of your weekly class schedule. Classes will automatically repeat every week. Our AI will extract the class times and days automatically.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!preview ? (
            <label
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`relative block border-2 border-dashed rounded-xl p-12 text-center transition-colors cursor-pointer ${
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/25 hover:border-primary/50"
              }`}
              data-testid="dropzone-schedule"
              htmlFor="schedule-file-input"
            >
              <input
                id="schedule-file-input"
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="sr-only"
                data-testid="input-file-schedule"
              />
              <div className="flex flex-col items-center gap-4">
                <div className="rounded-full bg-muted p-4">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-lg font-medium">Drag and drop your schedule image</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    or click to browse files (PNG, JPG, JPEG)
                  </p>
                </div>
              </div>
            </label>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={preview}
                  alt="Schedule preview"
                  className="w-full max-h-96 object-contain rounded-lg border"
                  data-testid="img-schedule-preview"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm"
                  onClick={clearUpload}
                  data-testid="button-clear-upload"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {uploadMutation.isPending && (
                <div className="flex items-center justify-center gap-2 p-4 rounded-lg bg-muted">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <span className="text-sm font-medium">Analyzing your schedule with AI...</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {extractedClasses.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Extracted Classes
                </CardTitle>
                <CardDescription>
                  Review the classes extracted from your schedule. Click save to add them to your calendar.
                </CardDescription>
              </div>
              <Button
                onClick={() => saveMutation.mutate(extractedClasses)}
                disabled={saveMutation.isPending}
                data-testid="button-save-classes"
              >
                {saveMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Saving...
                  </>
                ) : (
                  "Save All Classes"
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {extractedClasses.map((cls, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border"
                  data-testid={`card-class-${index}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Image className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{cls.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {getDayName(cls.dayOfWeek)} • {cls.startTime} - {cls.endTime}
                        {cls.location && ` • ${cls.location}`}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <ClassesPanel />

      <Card>
        <CardHeader>
          <CardTitle className="text-xl flex items-center gap-2">
            <SiGooglecalendar className="h-5 w-5 text-blue-500" />
            Google Calendar Integration
          </CardTitle>
          <CardDescription>
            Connect your Google account to import calendar events directly into your schedule.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Connection Status */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 rounded-lg bg-muted/50 border">
            <div className="flex-1">
              {isLoadingStatus ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">Checking connection...</span>
                </div>
              ) : googleStatus?.needsCredentials ? (
                <>
                  <p className="font-medium flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-yellow-500" />
                    Setup Required
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Google OAuth credentials need to be configured. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to enable calendar connection.
                  </p>
                </>
              ) : googleStatus?.connected ? (
                <>
                  <p className="font-medium flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Connected
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {googleStatus.email 
                      ? `Connected as ${googleStatus.email}`
                      : "Your Google Calendar is connected."}
                  </p>
                </>
              ) : (
                <>
                  <p className="font-medium">Connect Your Calendar</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Connect your Google account to import calendar events.
                  </p>
                </>
              )}
            </div>
            
            {!isLoadingStatus && !googleStatus?.needsCredentials && (
              <div className="flex gap-2">
                {googleStatus?.connected ? (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => disconnectMutation.mutate()}
                    disabled={disconnectMutation.isPending}
                    data-testid="button-disconnect-google"
                  >
                    {disconnectMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Unlink className="h-4 w-4 mr-2" />
                        Disconnect
                      </>
                    )}
                  </Button>
                ) : (
                  <Button 
                    onClick={() => connectMutation.mutate()}
                    disabled={connectMutation.isPending}
                    data-testid="button-connect-google"
                  >
                    {connectMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Link2 className="h-4 w-4 mr-2" />
                        Connect Google Calendar
                      </>
                    )}
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Import Section - Only show when connected */}
          {googleStatus?.connected && (
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 rounded-lg bg-muted/50 border">
              <div className="flex-1">
                <p className="font-medium">Import Calendar Events</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Import your upcoming events from Google Calendar as recurring classes.
                </p>
              </div>
              <Button 
                variant="outline" 
                className="shrink-0"
                onClick={() => googleImportMutation.mutate()}
                disabled={googleImportMutation.isPending}
                data-testid="button-import-google-calendar"
              >
                {googleImportMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Calendar className="h-4 w-4 mr-2" />
                    Import Events
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
