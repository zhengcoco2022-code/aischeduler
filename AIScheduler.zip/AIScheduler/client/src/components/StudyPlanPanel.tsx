import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Brain, Clock, Target, AlertTriangle, Lightbulb, ArrowRight, CheckCircle2, CalendarPlus, Zap, Shield, Scale, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface StudySession {
  taskId: string;
  taskName: string;
  dayOfWeek: number;
  scheduledDate: string;
  startTime: string;
  endTime: string;
}

interface StudyPlanOption {
  id: string;
  name: string;
  description: string;
  totalHours: number;
  sessionsPerDay: Record<string, number>;
  sessions: StudySession[];
  pros: string[];
  cons: string[];
}

interface StudyPlanWithOptions {
  overallAdvice: string;
  weeklyGoals: string[];
  warnings: string[];
  planOptions: StudyPlanOption[];
}

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function getPlanIcon(id: string) {
  switch (id) {
    case "conservative":
      return <Shield className="h-5 w-5 text-green-500" />;
    case "balanced":
      return <Scale className="h-5 w-5 text-blue-500" />;
    case "intensive":
      return <Zap className="h-5 w-5 text-orange-500" />;
    default:
      return <Brain className="h-5 w-5 text-primary" />;
  }
}

function getPlanBadgeColor(id: string) {
  switch (id) {
    case "conservative":
      return "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300";
    case "balanced":
      return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300";
    case "intensive":
      return "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300";
    default:
      return "";
  }
}

export function StudyPlanPanel() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  
  const generatePlanMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/schedule/study-plan-options");
      return res.json();
    },
    onSuccess: (data: StudyPlanWithOptions) => {
      queryClient.setQueryData(["/api/study-plan-options"], data);
      setSelectedPlan(null);
      toast({
        title: "Study plans generated",
        description: "Choose the plan that works best for you!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate study plans",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const applyPlanMutation = useMutation({
    mutationFn: async (sessions: StudySession[]) => {
      const res = await apiRequest("POST", "/api/schedule/apply-plan-option", { sessions });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-blocks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/schedule/health"] });
      toast({
        title: "Schedule updated!",
        description: data.message || "Your study plan has been applied to your calendar.",
      });
      setLocation("/schedule");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to apply study plan",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { data: studyPlanOptions } = useQuery<StudyPlanWithOptions>({
    queryKey: ["/api/study-plan-options"],
    enabled: false,
  });

  const plan = generatePlanMutation.data || studyPlanOptions;

  const handleApplyPlan = (planOption: StudyPlanOption) => {
    applyPlanMutation.mutate(planOption.sessions);
  };

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold" data-testid="text-study-plan-title">AI Study Planner</h1>
          <p className="text-muted-foreground mt-1">
            Generate personalized study plans and choose the one that fits your style
          </p>
        </div>
        <Button
          onClick={() => generatePlanMutation.mutate()}
          disabled={generatePlanMutation.isPending}
          data-testid="button-generate-plan"
        >
          {generatePlanMutation.isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Generating Plans...
            </>
          ) : (
            <>
              <Brain className="h-4 w-4 mr-2" />
              Generate Study Plans
            </>
          )}
        </Button>
      </div>

      {!plan && !generatePlanMutation.isPending && (
        <Card>
          <CardContent className="p-12 text-center">
            <Brain className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Get Multiple Study Plan Options</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-6">
              AI will analyze your schedule, tasks, and preferences to create 3 different study plans - from relaxed to intensive. Choose the one that fits your style!
            </p>
            <div className="flex justify-center gap-4 mb-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4 text-green-500" />
                <span>Conservative</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Scale className="h-4 w-4 text-blue-500" />
                <span>Balanced</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Zap className="h-4 w-4 text-orange-500" />
                <span>Intensive</span>
              </div>
            </div>
            <Button
              onClick={() => generatePlanMutation.mutate()}
              disabled={generatePlanMutation.isPending}
              data-testid="button-generate-plan-cta"
            >
              <Brain className="h-4 w-4 mr-2" />
              Generate Study Plans
            </Button>
          </CardContent>
        </Card>
      )}

      {generatePlanMutation.isPending && (
        <Card>
          <CardContent className="p-12 text-center">
            <Loader2 className="h-16 w-16 mx-auto text-primary animate-spin mb-4" />
            <h3 className="text-lg font-medium mb-2">Creating Your Study Plans</h3>
            <p className="text-muted-foreground">
              AI is analyzing your schedule and generating 3 different plan options...
            </p>
          </CardContent>
        </Card>
      )}

      {plan && !generatePlanMutation.isPending && (
        <div className="space-y-6">
          {/* Overall Advice */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-amber-500" />
                AI Advice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground" data-testid="text-overall-advice">
                {plan.overallAdvice}
              </p>
            </CardContent>
          </Card>

          {/* Warnings */}
          {plan.warnings && plan.warnings.length > 0 && (
            <Card className="border-amber-500/50">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-5 w-5" />
                  Important Warnings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {plan.warnings.map((warning, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-amber-700 dark:text-amber-300">
                      <ArrowRight className="h-4 w-4 mt-1 flex-shrink-0" />
                      <span data-testid={`text-warning-${idx}`}>{warning}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Weekly Goals */}
          {plan.weeklyGoals && plan.weeklyGoals.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Weekly Goals
                </CardTitle>
                <CardDescription>Focus on these objectives this week</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.weeklyGoals.map((goal, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span data-testid={`text-goal-${idx}`}>{goal}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Plan Options */}
          {plan.planOptions && plan.planOptions.length > 0 && (
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="text-xl font-semibold">Choose Your Study Plan</h2>
                <p className="text-muted-foreground mt-1">
                  Scroll down to compare all 3 plans. Each respects your sleep, lunch, and dinner times.
                </p>
              </div>
              
              <div className="space-y-8">
                {plan.planOptions.map((option, planIndex) => (
                  <Card 
                    key={option.id}
                    className={`transition-all ${
                      selectedPlan === option.id 
                        ? "ring-2 ring-primary shadow-lg" 
                        : "hover:shadow-md"
                    }`}
                    data-testid={`card-plan-${option.id}`}
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center h-10 w-10 rounded-full bg-muted">
                            {getPlanIcon(option.id)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <CardTitle className="text-xl">{option.name}</CardTitle>
                              <Badge variant="outline" className="text-xs">
                                Plan {planIndex + 1} of {plan.planOptions.length}
                              </Badge>
                            </div>
                            <CardDescription className="mt-1">{option.description}</CardDescription>
                          </div>
                        </div>
                        {selectedPlan === option.id && (
                          <div className="flex items-center gap-2 text-primary">
                            <Check className="h-5 w-5" />
                            <span className="text-sm font-medium">Selected</span>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Stats Row */}
                      <div className="flex items-center gap-4 flex-wrap">
                        <Badge className={`${getPlanBadgeColor(option.id)} text-sm px-3 py-1`}>
                          <Clock className="h-4 w-4 mr-1.5" />
                          {(option.totalHours || 0).toFixed(1)} hours total
                        </Badge>
                        <Badge variant="outline" className="text-sm px-3 py-1">
                          {(option.sessions || []).length} study sessions
                        </Badge>
                      </div>

                      {/* Full Session Schedule - grouped by day */}
                      {option.sessions && option.sessions.length > 0 && (
                        <div className="border rounded-lg p-4 bg-muted/30">
                          <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                            <CalendarPlus className="h-4 w-4" />
                            Session Schedule
                          </h4>
                          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                            {Object.entries(
                              option.sessions.reduce((acc, session) => {
                                const dateKey = session.scheduledDate;
                                if (!acc[dateKey]) acc[dateKey] = [];
                                acc[dateKey].push(session);
                                return acc;
                              }, {} as Record<string, typeof option.sessions>)
                            )
                              .sort(([a], [b]) => a.localeCompare(b))
                              .map(([date, sessions]) => (
                                <div key={date} className="bg-background rounded-md p-3 border">
                                  <p className="text-sm font-semibold text-foreground mb-2 pb-2 border-b">
                                    {DAY_NAMES[sessions[0].dayOfWeek]} {date.split('-').slice(1).join('/')}
                                  </p>
                                  <div className="space-y-2">
                                    {sessions.map((session, sIdx) => (
                                      <div 
                                        key={sIdx} 
                                        className="flex items-center gap-2 text-sm"
                                      >
                                        <span className="font-mono text-xs bg-muted px-2 py-1 rounded shrink-0">
                                          {session.startTime}-{session.endTime}
                                        </span>
                                        <span className="text-muted-foreground">{session.taskName}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                          </div>
                        </div>
                      )}

                      {/* Pros & Cons */}
                      <div className="grid md:grid-cols-2 gap-4">
                        {option.pros && option.pros.length > 0 && (
                          <div className="border rounded-lg p-4 bg-green-50/50 dark:bg-green-900/10">
                            <h4 className="text-sm font-semibold text-green-600 dark:text-green-400 mb-3 flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4" />
                              Advantages
                            </h4>
                            <ul className="space-y-2">
                              {option.pros.map((pro, idx) => (
                                <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                                  <span className="text-green-500 mt-0.5 shrink-0">+</span>
                                  <span>{pro}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {option.cons && option.cons.length > 0 && (
                          <div className="border rounded-lg p-4 bg-red-50/50 dark:bg-red-900/10">
                            <h4 className="text-sm font-semibold text-red-600 dark:text-red-400 mb-3 flex items-center gap-2">
                              <AlertTriangle className="h-4 w-4" />
                              Considerations
                            </h4>
                            <ul className="space-y-2">
                              {option.cons.map((con, idx) => (
                                <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                                  <span className="text-red-500 mt-0.5 shrink-0">-</span>
                                  <span>{con}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      {/* Apply Button */}
                      <Button
                        className="w-full"
                        size="lg"
                        variant={selectedPlan === option.id ? "default" : "outline"}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPlan(option.id);
                          handleApplyPlan(option);
                        }}
                        disabled={applyPlanMutation.isPending}
                        data-testid={`button-apply-${option.id}`}
                      >
                        {applyPlanMutation.isPending && selectedPlan === option.id ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Applying Plan...
                          </>
                        ) : (
                          <>
                            <CalendarPlus className="h-4 w-4 mr-2" />
                            Apply {option.name}
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Selected Plan Details */}
              {selectedPlan && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-primary" />
                      Schedule Preview: {plan.planOptions.find(p => p.id === selectedPlan)?.name}
                    </CardTitle>
                    <CardDescription>
                      Detailed session breakdown for your selected plan
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {(plan.planOptions
                        .find(p => p.id === selectedPlan)
                        ?.sessions || []).map((session, idx) => (
                          <div 
                            key={idx}
                            className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                            data-testid={`session-${idx}`}
                          >
                            <div className="flex items-center gap-3">
                              <div className="h-2 w-2 rounded-full bg-emerald-500" />
                              <div>
                                <p className="font-medium text-sm">{session.taskName}</p>
                                <p className="text-xs text-muted-foreground">
                                  {DAY_NAMES[session.dayOfWeek]}, {session.scheduledDate}
                                </p>
                              </div>
                            </div>
                            <Badge variant="outline">
                              {session.startTime} - {session.endTime}
                            </Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {plan.planOptions && plan.planOptions.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto text-green-500 mb-4" />
                <h3 className="text-lg font-medium mb-2">All Caught Up!</h3>
                <p className="text-muted-foreground">
                  You don't have any pending tasks. Add some tasks to get personalized study plans.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
